export const defaultCompare = (a: any, b: any) => (a < b ? -1 : a > b ? 1 : 0);
