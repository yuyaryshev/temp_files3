import { expect } from "chai";

describe(`temp_tests`, function() {
    it(`temp test1`, function() {
        //
        // const m1 = new Map();
        // const m2 = new Map();
        // m1.set(1,1);
        // m2.set(1,2);
        // expect(deepEqual(m1,m2)).to.equal(false);
        //
        // console.log("started111!!");
        expect(1).to.equal(1);
    });
});
