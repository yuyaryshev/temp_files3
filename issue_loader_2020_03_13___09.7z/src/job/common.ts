export interface MainIssueJobTInput {
    issueId: string;
    expand?: string[];
}
