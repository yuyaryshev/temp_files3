import { awaitDelay, ReversePromise, reversePromiseResolveItem } from "Ystd";
import { Job } from "./Job";
import { JobStorage } from "./JobStorage";
import { makeJobContextKey } from "./makeJobKey";
import { JobUnloadException } from "./JobUnloadException";
import uuid from "uuid";
import { runJob } from "./mainLogic_JobLifeCycle";
import { JobContext } from "Yjob/JobContext";

export type ExtractInputFunc<TEnv = any, TContext extends JobContext<any> = any, TContextIn = any, TIn = any> = (
    env: TEnv,
    input: TIn & TContextIn
) => { contextInput: TContextIn; jobInput: TIn };

export interface JobContextTypeInput<TEnv = any, TContext extends JobContext<unknown> = any, TContextIn = any> {
    cpl: string;
    type: string;
    maxRunningTasks?: number;
    extractInputFunc: ExtractInputFunc;
}

export class JobContextType<TEnv = any, TContext extends JobContext<any> = any, TContextIn = any>
    implements JobContextTypeInput<TEnv, TContext, TContextIn> {
    cpl: string;
    type: string;
    maxRunningTasks: number;
    extractInputFunc: ExtractInputFunc;

    constructor(input: JobContextTypeInput<TEnv, TContext, TContextIn>) {
        this.cpl = input.cpl;
        this.type = input.type;
        this.maxRunningTasks = input.maxRunningTasks || Infinity;
        this.extractInputFunc = input.extractInputFunc;

        if (!this.cpl || !this.cpl.length) throw new Error(`CODE00000303 Can't create JobContextType without cpl!`);
        if (!this.type || !this.type.length)
            throw new Error(`CODE00000304 Can't create JobContextType type === undefined or empty !`);
    }

    open(
        jobStorage: JobStorage<TEnv>,
        parent: Job | undefined,
        input: TContextIn,
        forceStale?: boolean,
        extendedFields?: any,
        creationReversePromise?: ReversePromise
    ): TContext {
        const {contextInput, jobInput} = this.extractInputFunc(jobStorage.env, input);
        const key = makeJobContextKey(this, contextInput);

        // Try to find job result in parent's context
        if (parent) {
            const depItem = parent.deps.get(key);
            if (depItem?.succeded) {
                return depItem.result;
            }
        }

        // Not found in context, search in JobStorage or create a new job
        let id = uuid();
        let jobContext: JobContext = jobStorage.findOrLoadJobContextByKey(key)!;
        if (!jobContext) {
            jobContext = new JobContext(this, jobStorage, input, id, key);
            for (let handler of jobContext.jobStorage.onJobContextCreatedHandlers) handler(jobContext, "CODE00000305");
        }
        if (extendedFields)
            for (let fieldKey in extendedFields)
                if (
                    extendedFields.hasOwnProperty(fieldKey) &&
                    (jobContext as any)[fieldKey] !== extendedFields[fieldKey]
                )
                    (jobContext as any)[fieldKey] = extendedFields[fieldKey];

        if (forceStale) {
            // TODO iterate all jobs and make them stale
            throw new Error(`CODE00000234 not implemented - iterate all jobs and make them stale`);
            //jobContext.makeStale();
        }

        reversePromiseResolveItem(creationReversePromise);

        return jobContext as TContext;
    }
}
