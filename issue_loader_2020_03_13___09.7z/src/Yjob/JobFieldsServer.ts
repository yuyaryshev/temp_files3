import { Job } from "./Job";
import { JobFieldFuncs, JobStorage } from "./JobStorage";
import { JobContext } from "./JobContext";

import moment from "moment";
// @ts-ignore
require("moment-countdown");

export const defaultJobFieldFuncs = {
    jobColumnStr:
        "id, key, jobsById, priority, cancelled, deps_succeded, createdTs, finishedTs, jobContextType, succeded, startedTs, prevError, retryIntervalIndex, nextRunTs, input, paused, timesSaved, updatedTs, deleted",
    jobColumnPlaceholderStr: "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?",

    serializeStatus: function serializeStatus(j: JobContext): DefaultJobContextStatus {
        const input = j.input;

        const jobsById = {} as DefaultSerializedJobs;
        for (let jobId in j.jobsById) {
            const sj = j.jobsById[jobId];
            jobsById[jobId] = {
                jobType: sj.jobType.type,
                id: sj.id,
                key: sj.key,
                priority: sj.priority,
                cancelled: sj.cancelled ? 1 : 0,
                deps_succeded: sj.deps_succeded ? 1 : 0,
                createdTs: sj.createdTs.format(),
                finishedTs: sj.finishedTs ? sj.finishedTs.format() : undefined,
                succeded: sj.succeded ? 1 : 0,
                startedTs: sj.startedTs ? sj.startedTs.format() : undefined,
                prevError: sj.prevError,
                retryIntervalIndex: sj.retryIntervalIndex,
                nextRunTs: sj.nextRunTs ? sj.nextRunTs.format() : undefined,
                input: JSON.stringify(input),
                prevResult: JSON.stringify(sj.prevResult),
                paused: sj.paused ? 1 : 0,
            };
        }

        return {
            deleted: 0,
            updatedTs: moment().format(),
            jobsById,
            jobContextType: j.jobContextType.type,
            id: j.id,
            key: j.key,
            priority: j.priority,
            cancelled: j.cancelled ? 1 : 0,
            deps_succeded: j.deps_succeded ? 1 : 0,
            createdTs: j.createdTs.format(),
            finishedTs: j.finishedTs ? j.finishedTs.format() : undefined,
            succeded: j.succeded ? 1 : 0,
            startedTs: j.startedTs ? j.startedTs.format() : undefined,
            prevError: j.prevError,
            retryIntervalIndex: j.retryIntervalIndex,
            nextRunTs: j.nextRunTs ? j.nextRunTs.format() : undefined,
            input: JSON.stringify(input),
            paused: j.paused ? 1 : 0,
            timesSaved: j.timesSaved,
        };
    },
    serialize: function serialize(j: JobContext): DefaultSerializedJobContext {
        const input = j.input;

        const jobsById = {} as DefaultSerializedJobs;
        for (let jobId in j.jobsById) {
            const sj = j.jobsById[jobId];
            jobsById[jobId] = {
                jobType: sj.jobType.type,
                id: sj.id,
                key: sj.key,
                priority: sj.priority,
                cancelled: sj.cancelled ? 1 : 0,
                deps_succeded: sj.deps_succeded ? 1 : 0,
                createdTs: sj.createdTs.format(),
                finishedTs: sj.finishedTs ? sj.finishedTs.format() : undefined,
                succeded: sj.succeded ? 1 : 0,
                startedTs: sj.startedTs ? sj.startedTs.format() : undefined,
                prevError: sj.prevError,
                retryIntervalIndex: sj.retryIntervalIndex,
                nextRunTs: sj.nextRunTs ? sj.nextRunTs.format() : undefined,
                input: JSON.stringify(input),
                prevResult: JSON.stringify(sj.prevResult),
                paused: sj.paused ? 1 : 0,
            };
        }

        return {
            updatedTs: moment().format(),
            jobsById,
            jobContextType: j.jobContextType.type,
            id: j.id,
            key: j.key,
            priority: j.priority,
            cancelled: j.cancelled ? 1 : 0,
            deps_succeded: j.deps_succeded ? 1 : 0,
            createdTs: j.createdTs.format(),
            finishedTs: j.finishedTs ? j.finishedTs.format() : undefined,
            succeded: j.succeded ? 1 : 0,
            startedTs: j.startedTs ? j.startedTs.format() : undefined,
            prevError: j.prevError,
            retryIntervalIndex: j.retryIntervalIndex,
            nextRunTs: j.nextRunTs ? j.nextRunTs.format() : undefined,
            input: JSON.stringify(input),
            paused: j.paused ? 1 : 0,
            timesSaved: j.timesSaved,
        };
    },
    serializeToArray: function serializedToArray(o: DefaultSerializedJobContext) {
        return [
            o.id,
            o.key,
            o.priority,
            o.cancelled,
            o.deps_succeded,
            o.createdTs,
            o.finishedTs,
            o.succeded,
            o.startedTs,
            o.prevError,
            o.retryIntervalIndex,
            o.nextRunTs,
            o.input,
            o.paused,
            o.timesSaved,
        ];
    },

    deserialize: function deserialize<TEnv>(jobStorage: JobStorage<TEnv, any, any, any, any, any, any, any>, row: any): JobContext {
        for (let k in row) if (row[k] === null) delete row[k];
        const serialized: DefaultSerializedJobContext = row;
        serialized.input = serialized.input ? JSON.parse(serialized.input) : {};

        const jobContextType = jobStorage.allJobContextTypes[serialized.jobContextType];
        if (!jobContextType) throw new Error(`CODE00000000 jobContextType=${serialized.jobContextType} - not found!`);

        const r = new JobContext(jobContextType, jobStorage, serialized.input, serialized.id, serialized.key);

        r.priority = serialized.priority;
        r.cancelled = !!serialized.cancelled;
        r.deps_succeded = !!serialized.deps_succeded;
        r.createdTs = moment(serialized.createdTs);
        r.finishedTs = serialized.finishedTs ? moment(serialized.finishedTs) : undefined;
        r.succeded = !!serialized.succeded;
        r.startedTs = serialized.startedTs ? moment(serialized.startedTs) : undefined;
        r.prevError = serialized.prevError;
        r.retryIntervalIndex = serialized.retryIntervalIndex;
        r.nextRunTs = serialized.nextRunTs ? moment(serialized.nextRunTs) : undefined;
        r.paused = !!serialized.paused;
        r.timesSaved = serialized.timesSaved;

        r.jobsById = {} as any;
        for (let jobId in serialized.jobsById) {
            const serializedJob = serialized.jobsById[jobId];

            const jobType = jobStorage.allJobTypes[serializedJob.jobType];
            if (!jobType) throw new Error(`CODE00000000 jobType=${serializedJob.jobType} - not found!`);

            const jr = new Job(jobType, r, serializedJob.input, serializedJob.id, serializedJob.key, serializedJob.parent);

            jr.priority = serializedJob.priority;
            jr.cancelled = !!serializedJob.cancelled;
            jr.deps_succeded = !!serializedJob.deps_succeded;
            jr.createdTs = moment(serializedJob.createdTs);
            jr.finishedTs = serializedJob.finishedTs ? moment(serializedJob.finishedTs) : undefined;
            jr.succeded = !!serializedJob.succeded;
            jr.startedTs = serializedJob.startedTs ? moment(serializedJob.startedTs) : undefined;
            jr.prevError = serializedJob.prevError;
            jr.retryIntervalIndex = serializedJob.retryIntervalIndex;
            jr.nextRunTs = serializedJob.nextRunTs ? moment(serializedJob.nextRunTs) : undefined;
            jr.prevResult = serializedJob.prevResult && JSON.parse(serializedJob.prevResult);
            jr.paused = !!serializedJob.paused;

            r.jobsById[jobId] = jr;
            //r.jobsByKey[jr.key] = jr;
        }
        return r;
    },
};

/* Client class declaraion
export class JobStatus {
    @observable id: string="";
    @observable key: string="";
    @observable priority: number | undefined=0;
    @observable cancelled: number=0;
    @observable deps_succeded: number=0;
    @observable createdTs: string="";
    @observable finishedTs: string | undefined="";
    @observable jobType: string="";
    @observable succeded: number=0;
    @observable startedTs: string | undefined="";
    @observable prevError: string | undefined="";
    @observable retryIntervalIndex: number=0;
    @observable nextRunTs: string | undefined="";
    @observable input: any=undefined;
    @observable prevResult: any | undefined=undefined;
    @observable paused: number=0;
};

export class JobContextStatus {
    @observable id: string="";
    @observable key: string="";
    @observable jobsById: any={};
    @observable priority: number | undefined=0;
    @observable cancelled: number=0;
    @observable deps_succeded: number=0;
    @observable createdTs: string="";
    @observable finishedTs: string | undefined="";
    @observable jobContextType: string="";
    @observable succeded: number=0;
    @observable startedTs: string | undefined="";
    @observable prevError: string | undefined="";
    @observable retryIntervalIndex: number=0;
    @observable nextRunTs: string | undefined="";
    @observable input: any=undefined;
    @observable paused: number=0;
    @observable timesSaved: number=0;
    @observable updatedTs: string="";
    @observable deleted: number | undefined=0;
};
*/

export interface DefaultJobStatus {
    id: string;
    key: string;
    priority: number | undefined;
    cancelled: number;
    deps_succeded: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    prevResult: any | undefined;
    paused: number;
}

export interface DefaultSerializedJob {
    id: string;
    key: string;
    priority: number | undefined;
    cancelled: number;
    deps_succeded: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    prevResult: any | undefined;
    paused: number;
}

export interface DefaultSerializedJobs {
    [key: string]: DefaultSerializedJob;
}

export interface DefaultJobsStatus {
    [key: string]: DefaultJobStatus;
}

export interface DefaultJobContextStatus {
    id: string;
    key: string;
    jobsById: any;
    priority: number | undefined;
    cancelled: number;
    deps_succeded: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobContextType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    paused: number;
    timesSaved: number;
    updatedTs: string;
    deleted: number | undefined;
}

export interface DefaultSerializedJobContext {
    id: string;
    key: string;
    jobsById: any;
    priority: number | undefined;
    cancelled: number;
    deps_succeded: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobContextType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    paused: number;
    timesSaved: number;
    updatedTs: string;
}
