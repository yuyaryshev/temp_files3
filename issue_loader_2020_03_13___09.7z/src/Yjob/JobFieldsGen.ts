import { assertNever } from "assert-never";
import { fjmap, formatTypescript, projectDirResolve, strReplace, writeFileSyncIfChanged } from "Ystd";
import { JobFieldInput, JobFieldMeta, makeFieldFromInput } from "Yjob/JobFieldMeta";

export const jobFieldInputs: JobFieldInput[] = [
    { baseField: true, fname: "id", type: "string", skipDeserialize: true },
    { baseField: true, fname: "key", type: "string", skipDeserialize: true },
    { baseField: true, fname: "priority", type: "number", optional: true },
    { baseField: true, fname: "cancelled", type: "boolean" },
    { baseField: true, fname: "deps_succeded", type: "boolean" },
    { baseField: true, fname: "createdTs", type: "ts" },
    { baseField: true, fname: "finishedTs", type: "ts", optional: true },
    { baseField: true, fname: "jobType", type: "link", skipSerialize: true },
    { baseField: true, fname: "succeded", type: "boolean" },
    { baseField: true, fname: "startedTs", type: "ts", optional: true },
    { baseField: true, fname: "prevError", type: "string", optional: true },
    { baseField: true, fname: "retryIntervalIndex", type: "number" },
    { baseField: true, fname: "nextRunTs", type: "ts", optional: true },
    { baseField: true, fname: "input", type: "json", skipDeserialize: true },
    { baseField: true, fname: "prevResult", type: "json", optional: true },
    { baseField: true, fname: "paused", type: "boolean" },
];

export const contextFieldInputs: JobFieldInput[] = [
    { baseField: true, fname: "id", type: "string", skipDeserialize: true },
    { baseField: true, fname: "key", type: "string", skipDeserialize: true },
    { baseField: true, fname: "jobsById", type: "JobDict", skipSerialize: true },
//    { baseField: true, fname: "jobsByKey", type: "JobDict", skipSerialize: true },
    { baseField: true, fname: "priority", type: "number", optional: true },
    { baseField: true, fname: "cancelled", type: "boolean" },
    { baseField: true, fname: "deps_succeded", type: "boolean" },
    { baseField: true, fname: "createdTs", type: "ts" },
    { baseField: true, fname: "finishedTs", type: "ts", optional: true },
    { baseField: true, fname: "jobContextType", type: "link", skipSerialize: true },
    { baseField: true, fname: "succeded", type: "boolean" },
    { baseField: true, fname: "startedTs", type: "ts", optional: true },
    { baseField: true, fname: "prevError", type: "string", optional: true },
    { baseField: true, fname: "retryIntervalIndex", type: "number" },
    { baseField: true, fname: "nextRunTs", type: "ts", optional: true },
    { baseField: true, fname: "input", type: "json", skipDeserialize: true },
    { baseField: true, fname: "paused", type: "boolean" },
    { baseField: true, fname: "timesSaved", type: "number" },
    { baseField: true, fname: "updatedTs", type: "ts", skipSerialize: true },
    { baseField: true, fname: "deleted", type: "boolean", statusOnly: true },
];

type getSerializeMode = ["io", "status", "client"];

function genSerializedInterface(interfaceName: string, jobFields: JobFieldMeta[]) {
    const status = interfaceName.includes("Status");
    return `    
export interface ${interfaceName} {
    ${fjmap(jobFields, ",\n        ", f => (!f.statusOnly || status ? f.interfaceFieldStr : undefined))}        
}
`;
}

export function genSerializeFields(jobFields: JobFieldMeta[]) {
    const hasInputFields = !!jobFields.filter(f => f.inputField).length;

    return {
        hasInputFields,
        serializeExplodeFieldStr: hasInputFields
            ? `const { ${fjmap(jobFields, ", ", f => f.inputField)}, ...input} = (j.input as any);`
            : "const input = j.input",
        serializeFieldStr: fjmap(jobFields, ",\n        ", f => f.serialize),
        serializeStatusFieldStr: fjmap(jobFields, ",\n        ", f => f.serializeToStatus),
        deserializeRestoreInputStr: fjmap(jobFields, ";    ", f => f.deserializeRestoreInput),
        deserializeFieldStr: fjmap(jobFields, ";\n        ", f => f.deserialize),
    };
}

function genSerializeJobFunction(
    contextFields: JobFieldMeta[],
    jobFields: JobFieldMeta[],
    status: boolean,
    libMode: boolean,
) {
    const defaultStr = (libMode ? "Default" : "");
    const statusStr = (status ? "Status" : "");
    const { serializeExplodeFieldStr} = genSerializeFields(contextFields);
    return `
serialize${statusStr}: function serialize${statusStr}(j: JobContext): ${defaultStr}${status ? "JobContextStatus" : "SerializedJobContext"} {
    ${serializeExplodeFieldStr}

    const jobsById = {} as ${defaultStr}SerializedJobs;
    for(let jobId in j.jobsById) {
        const sj = j.jobsById[jobId];
        jobsById[jobId] = {
            jobType:sj.jobType.type,
            ${strReplace(fjmap(jobFields, ",\n            ", f => f.serialize), "j.", "sj.")}
        };
    }

    return {        
        ${status?`deleted:0,        `:""}
        updatedTs:moment().format(),        
        jobsById,
        jobContextType: j.jobContextType.type,
        ${fjmap(contextFields, ",\n        ", f => f.serialize)}
    };
}
`;
}

export interface JobFieldsGenOptions {
    targetPath: string;
    libMode: boolean;
    client: boolean;
    jobFields: JobFieldInput[];
    contextFields: JobFieldInput[];
}

export function generateJobFieldsTs(options: JobFieldsGenOptions) {
    const targetPath0 = options.targetPath;
    const { libMode, client } = options;
    const defaultStr = (libMode ? "Default" : "");
    const contextFields: JobFieldMeta[] = options.contextFields.map(makeFieldFromInput);
    const jobFields: JobFieldMeta[] = options.jobFields.map(makeFieldFromInput);
    const contextFieldAgg = genSerializeFields(contextFields);
    const jobFieldAgg = genSerializeFields(jobFields);

    const genSourceClient = formatTypescript(`
import { observable } from "mobx";

import moment from "moment";
// @ts-ignore
require("moment-countdown");

export class JobStatus {
    ${fjmap(jobFields, "\n    ", f => f.clientClassFieldStr)}
};

export class JobContextStatus {
    ${fjmap(contextFields, "\n    ", f => f.clientClassFieldStr)}
};
`);

    const genSourceServer = formatTypescript(`
import {Job} from ${libMode ? "\"./Job\"" : "\"Yjob\""};
import { JobFieldFuncs, JobStorage } from ${libMode ? "\"./JobStorage\"" : "\"Yjob\""};
import { JobContext } from ${libMode ? "\"./JobContext\"" : "\"Yjob\""};

import moment from "moment";
// @ts-ignore
require("moment-countdown");

export const ${options.libMode ? "defaultJobFieldFuncs" : "jobFieldFuncs"} = {
    jobColumnStr : ${JSON.stringify(fjmap(contextFields, ", ", f => f.fname))},
    jobColumnPlaceholderStr : ${JSON.stringify(fjmap(contextFields, ", ", f => "?"))},
    
    ${genSerializeJobFunction(
        contextFields,
        jobFields,
        true,
        options.libMode,
    )},    
    ${genSerializeJobFunction(
        contextFields,
        jobFields,
        false,
        options.libMode,
    )},

    serializeToArray:function serializedToArray(o: ${defaultStr}SerializedJobContext) {
    return [
        ${fjmap(contextFields,",    ",f => !f.skipSerialize && `o.${f.fname}` || undefined)}
    ]},
            
    
    deserialize:function deserialize<TEnv>(jobStorage: JobStorage<TEnv, any, any, any, any, any, any, any>, row: any): JobContext {
        for (let k in row) if (row[k] === null) delete row[k];
        const serialized: ${defaultStr}SerializedJobContext = row;
        serialized.input = serialized.input ? JSON.parse(serialized.input) : {};
        
        ${contextFieldAgg.deserializeRestoreInputStr}

        const jobContextType = jobStorage.allJobContextTypes[serialized.jobContextType];
        if (!jobContextType)
            throw new Error(\`CODE${"00000000"} jobContextType=\${serialized.jobContextType} - not found!\`);

        const r = new JobContext(jobContextType, jobStorage, serialized.input, serialized.id, serialized.key);
        
        ${contextFieldAgg.deserializeFieldStr}
        
        r.jobsById = {} as any;
        for(let jobId in serialized.jobsById) {
            const serializedJob = serialized.jobsById[jobId];

            const jobType = jobStorage.allJobTypes[serializedJob.jobType];
            if (!jobType)
                throw new Error(\`CODE${"00000000"} jobType=\${serializedJob.jobType} - not found!\`);

            const jr = new Job(jobType, r, serializedJob.input, serializedJob.id, serializedJob.key, serializedJob.parent);
            
            ${strReplace(strReplace(jobFieldAgg.deserializeFieldStr,"r.", "jr."),"serialized.", "serializedJob.")}
            
            r.jobsById[jobId] = jr;
            //r.jobsByKey[jr.key] = jr;
        }
        return r;
    }
    

}

/* Client class declaraion
export class JobStatus {
    ${fjmap(jobFields, "\n    ", f => f.clientClassFieldStr)}
};

export class JobContextStatus {
    ${fjmap(contextFields, "\n    ", f => f.clientClassFieldStr)}
};
*/

${genSerializedInterface(`${defaultStr}JobStatus`, jobFields)}
${genSerializedInterface(`${defaultStr}SerializedJob`, jobFields)}

export interface ${defaultStr}SerializedJobs {
    [key:string] : ${defaultStr}SerializedJob;
}

export interface ${defaultStr}JobsStatus {
    [key:string] : ${defaultStr}JobStatus;
}

${genSerializedInterface(`${defaultStr}JobContextStatus`, contextFields)}
${genSerializedInterface(`${defaultStr}SerializedJobContext`, contextFields)}

`);

    const targetPath = projectDirResolve(targetPath0);
    console.log(`targetPath = ${targetPath}`);
    writeFileSyncIfChanged(targetPath, client ? genSourceClient : genSourceServer);
}
