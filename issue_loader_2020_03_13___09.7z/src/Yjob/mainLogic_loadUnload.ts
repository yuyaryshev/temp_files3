import { Job } from "Yjob/Job";
import { sortObjects } from "Ystd";
import { JobStorage } from "Yjob/JobStorage";
import moment from "moment";

const jobsRatio = {
    veryLow: 0.1,
    low: 0.7,
    mid: 0.8,
    high: 0.9,
    max: 1,
};

export async function loadUnload(jobStorage: JobStorage<any, any, any, any, any, any, any, any>) {
    const ts = moment();
    const tsStr = ts.format();
    // const VERY_LOW = jobStorage.maxLoadedJobs * jobsRatio.veryLow;
    const LOW = jobStorage.maxLoadedJobs * jobsRatio.low;
    const MID = jobStorage.maxLoadedJobs * jobsRatio.mid;
    const HIGH = jobStorage.maxLoadedJobs * jobsRatio.high;
    const MAX = jobStorage.maxLoadedJobs * jobsRatio.max;

    // Load more jobs if some Jobs are unloaded to DB
    if (!jobStorage.nonSuccededJobsFullyLoaded) {
        // First we load ReadyToRun tasks.
        // HINT: We don't care if we have too much tasks here, because readyToRun tasks should always take priority
        // if we looad too many here, than we will unload some OTHER tasks below
        if (jobStorage.readyToRunJobs.length < LOW)
            jobStorage.loadJobContexts(
                jobStorage.selectReadyToRunByNextRunTs.iterate(tsStr, MID),
                () => MID <= jobStorage.readyToRunJobs.length
            );

        if (jobStorage.loadedJobsCount() < LOW)
            jobStorage.loadJobContexts(
                jobStorage.selectAllNotSucceded.iterate(MID),
                () => jobStorage.loadedJobsCount() <= MID
            );

        if (jobStorage.loadedJobsCount() < LOW) jobStorage.nonSuccededJobsFullyLoaded = true;
    }

    // We unload jobs only if we reached MAX
    // But we will unload them until there are less than HIGH jobs left
    // This is because unloading process is quite heavy and we don't want it to occur every time.
    if (jobStorage.loadedJobsCount() < MAX) return;

    // Additional check to prevent unloading too often
    if (jobStorage.lastUnload && jobStorage.lastUnload.diff(ts) < jobStorage.minUnloadInterval) return;
    jobStorage.lastUnload = ts;

    // First unload jobs which are waiting for time, which won't be needed for quire a long time
    for (let i = jobStorage.waitingTimeJobs.length - 1; i >= 0; i--) {
        const job = jobStorage.waitingTimeJobs[i];
        if (
            job.nextRunTs &&
            job.nextRunTs.diff(ts) > jobStorage.maxAwaitBeforeUnload &&
            job.touchTs.diff(ts) > jobStorage.maxAwaitBeforeUnload
        )
            await jobStorage.unload(job);
        if (jobStorage.loadedJobsCount() <= HIGH) return;
    }

    // Than unload jobs whose deps are not ready and which are not touched for quite long time
    for (let [, job] of jobStorage.jobContextById)
        if (!job.deps_succeded && ts.diff(job.touchTs) > jobStorage.maxAwaitBeforeUnload) {
            await jobStorage.unload(job);
            if (jobStorage.loadedJobsCount() <= HIGH) return;
        }

    // If we still have too much jobs - unload all non-ready to run by touchTs
    {
        const jobsByTouchTs: Job[] = sortObjects([...jobStorage.jobContextById.values()], ["touchTs"]);
        for (let i = jobsByTouchTs.length - 1; i >= 0; i--) {
            const job = jobsByTouchTs[i];
            if (!jobStorage.readyToRunJobs.includes(job)) {
                await jobStorage.unload(job);
                if (jobStorage.loadedJobsCount() <= HIGH) return;
            }
        }
    }

    // Only ready to run jobs are left, but still too many - unload them by touchTs
    {
        const jobsByTouchTs: Job[] = sortObjects([...jobStorage.readyToRunJobs], ["touchTs"]);
        for (let i = jobsByTouchTs.length - 1; i >= 0; i--) {
            const job = jobsByTouchTs[i];
            await jobStorage.unload(job);
            if (jobStorage.loadedJobsCount() <= HIGH) return;
        }
    }

    jobStorage.my_console.error(
        `CODE00000291`,
        `Internal error - Couldn't unload tasks, there are still ${jobStorage.loadedJobsCount()} tasks left!`
    );
}
