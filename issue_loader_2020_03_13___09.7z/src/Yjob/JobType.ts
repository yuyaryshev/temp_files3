import { awaitDelay, ReversePromise, reversePromiseResolveItem } from "Ystd";
import { Job, JobId, JobKey } from "./Job";
import { JobStorage } from "./JobStorage";
import { JobUnloadException } from "./JobUnloadException";
import uuid from "uuid";
import { runJob } from "./mainLogic_JobLifeCycle";
import { JobContext, JobContextKey } from "Yjob/JobContext";
import { JobContextType } from "Yjob/JobContextType";
import { makeJobContextKey, makeJobKey } from "Yjob/makeJobKey";

export type Deps = unknown;

export type GetContextInputFunc<
    TEnv = any,
    TContext extends JobContext<unknown> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> = (env: TEnv, job: Job<TIn, TOut>, input: TIn) => TContextIn;
export type PresetDepsFunc<
    TEnv = any,
    TContext extends JobContext<unknown> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> = (env: TEnv, job: Job<TIn, TOut>, input: TIn) => Deps;
export type JobFunc<TEnv = any, TContext extends JobContext<unknown> = any, TContextIn = any, TIn = any, TOut = any> = (
    env: TEnv,
    job: Job<TIn, TOut>,
    input: TIn
) => TOut | Promise<TOut>;

export interface JobTypeInput<
    TEnv = any,
    TContext extends JobContext<unknown> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> {
    cpl: string;
    type: string;
    maxRunningTasks?: number;
    jobContextType: JobContextType;
    getContextInputFunc: GetContextInputFunc<TEnv, TContext, TContextIn, TIn, TOut>;
    presetDepsFunc?: PresetDepsFunc<TEnv, TContext, TContextIn, TIn, TOut>;
    func: JobFunc<TEnv, TContext, TContextIn, TIn, TOut>;
}

export class JobType<TEnv = any, TContext extends JobContext<unknown> = any, TContextIn = any, TIn = any, TOut = any>
    implements JobTypeInput<TEnv, TContext, TContextIn, TIn, TOut> {
    cpl: string;
    type: string;
    maxRunningTasks: number;
    jobContextType: JobContextType;

    getContextInputFunc: GetContextInputFunc<TEnv, TContext, TContextIn, TIn, TOut>;
    presetDepsFunc?: PresetDepsFunc<TEnv, TContext, TContextIn, TIn, TOut>;
    func: JobFunc<TEnv, TContext, TContextIn, TIn, TOut>;

    constructor(input: JobTypeInput<TEnv, TContext, TContextIn, TIn, TOut>) {
        this.cpl = input.cpl;
        this.type = input.type;
        this.maxRunningTasks = input.maxRunningTasks || Infinity;
        this.jobContextType = input.jobContextType;

        if (!this.cpl || !this.cpl.length) throw new Error(`CODE00000293 Can't create JobType without cpl!`);
        if (!this.type || !this.type.length)
            throw new Error(`CODE00000294 Can't create JobType type === undefined or empty !`);

        this.getContextInputFunc = input.getContextInputFunc;
        this.presetDepsFunc = input.presetDepsFunc;
        this.func = input.func;
    }

    run(
        jobStorage: JobStorage<TEnv>,
        parent: Job | undefined,
        input: TIn & TContextIn,
        forceStale?: boolean,
        extendedFields?: any,
        creationReversePromise?: ReversePromise
    ): Promise<TOut | JobUnloadException> | TOut | JobUnloadException {
        const parentContext = parent?.jobContext;
        const { contextInput, jobInput } = this.jobContextType.extractInputFunc(jobStorage.env, input);
        const jobContextKey = makeJobContextKey(this.jobContextType, contextInput);
        const jobKey = makeJobKey(this, jobInput);

        let jobContext = parentContext?.key === jobContextKey ? parentContext : undefined;

        if (!jobContext && parentContext) {
            const depItem = parentContext.externalDeps_get(jobKey);
            if (depItem?.succeded) {
                reversePromiseResolveItem(creationReversePromise);
                return depItem.result;
            }
        }

        if (!jobContext) {
            jobContext = jobStorage.findOrLoadJobContextByKey(jobContextKey);
        }

        if (!jobContext) {
            const contextId = uuid();
            jobContext = new JobContext(
                this.jobContextType,
                jobStorage,
                jobInput,
                contextId,
                jobContextKey);
        }

        let job:Job = jobContext.getJobByKey(jobKey)!;
        if (!job) {
            const jobId = uuid();
            job = new Job<TEnv, TContext, TIn, TOut>(this, jobContext, input, jobId, jobKey, parent?.id);
            for (let handler of job.jobStorage.onJobCreatedHandlers) handler(job, "CODE00000295");
        }

        if (parentContext && jobContext.id !== parentContext.id)
            parentContext.externalDeps_set(jobKey, {
                succeded: false,
                id: job.id,
                jobContextId: jobContext.id,
                result: undefined,
            });

        // Not found in context, search in JobStorage or create a new job
        if (extendedFields)
            for (let fieldKey in extendedFields)
                if (extendedFields.hasOwnProperty(fieldKey) && (job as any)[fieldKey] !== extendedFields[fieldKey])
                    (job as any)[fieldKey] = extendedFields[fieldKey];

        if (forceStale) job.makeStale();

        reversePromiseResolveItem(creationReversePromise);

        // Function ending - save job result into parent's context and return the result
        const tailFunc = () => {
            if (parent) {
                parent.deps.set(job.key, {
                    id: job.id,
                    succeded: job.succeded,
                    result: job.prevResult,
                });
                return job.prevResult;
            }

            return job.prevResult;
        };

        // If the job is finished - return result immediatly
        if (job.succeded) return tailFunc();

        // Job isn't finished yet. Async mode...
        return (async function awaitRunJob() {
            if (!job.running) runJob(job); // NO AWAIT HERE! Await is below implemented with await awaitDelay & while!

            if (jobStorage.maxAwaitBeforeUnload <= 0) return new JobUnloadException("CODE00000296");

            // Wait for a while for job to finish without unloading it
            // Later unload the job if waiting for too long (jobStorage.maxAwaitBeforeUnload)
            let totalAwaitTime = 0;

            let delay = 10;
            while (totalAwaitTime < 50) {
                totalAwaitTime += delay;
                if (job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
                    return new JobUnloadException("CODE00000297");
                await awaitDelay(delay);
                if (job.succeded) return tailFunc();
            }

            delay = 30;
            while (totalAwaitTime < 500) {
                totalAwaitTime += delay;
                if (job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
                    return new JobUnloadException("CODE00000298");
                await awaitDelay(delay);
                if (job.succeded) return tailFunc();
            }

            delay = 100;
            while (totalAwaitTime < 5000) {
                totalAwaitTime += delay;
                if (job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
                    return new JobUnloadException("CODE00000299");
                await awaitDelay(delay);
                if (job.succeded) return tailFunc();
            }

            delay = 300;
            while (true) {
                totalAwaitTime += delay;
                if (job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
                    return new JobUnloadException("CODE00000300");
                await awaitDelay(delay);
                if (job.succeded) return tailFunc();
            }
        })();
    }
}

export async function throwUnload<T>(promise: Promise<T | JobUnloadException> | T | JobUnloadException) {
    const r = await promise;
    if (r instanceof JobUnloadException) throw r;
    return r;
}
