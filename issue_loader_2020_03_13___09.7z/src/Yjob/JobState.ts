export type JobState = "WaitingDeps" | "WaitingTime" | "ReadyToRun" | "Running" | "Done";
