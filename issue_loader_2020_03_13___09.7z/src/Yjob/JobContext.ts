// import { Database } from "better-sqlite3";
// import { SqliteLog } from "../SqliteLog";
// import { assertNever } from "assert-never";
// import { EnvSettings } from "../Env";
// import { runOnce } from "../runOnce";
import { JobWait } from "./JobWait";
import { JobStep } from "./JobStep";
import { JobType } from "./JobType";
import { JobStorage } from "./JobStorage";
import moment from "moment";
import { ObjectWithCont } from "Ystd";
import { JobContextType } from "Yjob/JobContextType";
import { Job, JobDependencyItem, JobId, JobKey } from "Yjob/Job";

export type JobContextId = string;
export type JobContextKey = string;

export interface ContextExtDeps {
    [key: string]: JobDependencyItem;
}

export class JobContext<TEnv = any, TContextIn = any> implements ObjectWithCont<JobContext> {
    // GRP_job_readonly_fields - immutable & readonly by Job system fields
    public readonly jobStorage: JobStorage<TEnv>;
    public readonly id: JobContextId;
    public readonly key: JobContextKey;
    public readonly jobContextType: JobContextType;
    public readonly input: TContextIn;
    public priority?: number;
    public createdTs: moment.Moment;

    public jobsById: { [key: string]: Job }; // JobId -> Job
    //public jobsByKey: { [key: string]: Job }; // JobKey -> Job
    public externalDeps: ContextExtDeps;

    // ------- Пересмотреть поля ниже. Вероятно часть удалить -------
    // ----------------------  GRP_job_fields ----------------------
    // GRP_job_flow_fields - shouldn't be modified from outside of Job system directly, - use functions to change some of this fields
    cancelled: boolean; // This flag is only used when the job is Running
    running: boolean;
    succeded: boolean;
    paused: boolean;
    deps_succeded: boolean;

    // GRP_scheduling
    retryIntervalIndex: number;
    nextRunTs?: moment.Moment;
    // get nextRunTs() {
    //     return this._nextRunTs;
    // }
    // set nextRunTs(v:moment.Moment | undefined) {
    //     if(v) {
    //         console.trace(`CODE00000059 REMOVE_THIS`, v?.format());
    //     }
    //     this._nextRunTs = v;
    // }

    // GRP_job_info_fields - writeonly fields, - job system writes to this fields and writes some them to DB as logs, but it never READS from it in JobCycle
    public startedTs?: moment.Moment;
    public finishedTs?: moment.Moment;
    public waitType: JobWait | undefined;
    public prevError: string | undefined;
    public timesSaved: number;
    //    public updatedTs?: moment.Moment;
    // ----------------------  GRP_job_fields END ----------------------

    public unloaded: boolean;
    public touchTs: moment.Moment;
    public jobSteps: JobStep[];
    public currentJobStep: JobStep;
    public container: JobContext[] | Set<JobContext> | undefined;

    constructor(
        jobContextType: JobContextType,
        jobStorage: JobStorage<TEnv>,
        input: TContextIn,
        id: string,
        key: string
    ) {
        // GRP_job_readonly_fields
        this.jobStorage = jobStorage;
        this.id = id;
        this.key = key;
        this.jobContextType = jobContextType;
        this.input = input;
        this.priority = undefined;
        this.createdTs = moment();
        this.jobsById = {};
        this.externalDeps = {};

        // GRP_job_ready_states
        this.cancelled = false;
        this.running = false;
        this.succeded = false;
        this.paused = false;
        this.deps_succeded = true;
        //this.observers = [];

        // GRP_job_scheduling
        this.retryIntervalIndex = 0;
        this.nextRunTs = undefined;

        // GRP_job_info_fields
        this.startedTs = undefined;
        this.finishedTs = undefined;
        this.waitType = undefined;
        this.prevError = undefined;
        this.timesSaved = 0;
        this.jobSteps = [];
        this.currentJobStep = undefined as any;
        this.touchTs = moment();
        this.unloaded = false;
    }

    save(saveHistory: boolean): Promise<void> {
        return this.jobStorage.saveJobContext(this, saveHistory);
    }

    touch() {
        this.jobStorage.touch(this);
    }

    unload() {
        return this.jobStorage.unload(this);
    }

    externalDeps_get(jobKey: JobKey): JobDependencyItem {
        return this.externalDeps[jobKey];
    }

    externalDeps_set(jobKey: JobKey, v: JobDependencyItem) {
        this.externalDeps[jobKey] = v;
    }

    jobsArray() {
        return Object.values(this.jobsById);
    }

    getJobById(jobId: JobId) {
        return this.jobsById[jobId];
    }

    getJobByKey(jobKey: JobKey) {
        //return this.jobsByKey[c];
        for (let i in this.jobsById) if (this.jobsById[i].key === jobKey) return this.jobsById[i];
        return undefined;
    }
}
