import { awaitDelay } from "Ystd";
import { JobStorage } from "Yjob/JobStorage";
import moment from "moment";
import { runJob, sch_ClearNext } from "Yjob/mainLogic_JobLifeCycle";

export async function startJobs(jobStorage: JobStorage<any, any, any, any, any, any, any, any>) {
    while (true) {
        jobStorage.haveNewSavesFlag = false;
        const nextWaitingJob = jobStorage.waitingTimeJobs[0];

        // Check if next jobs waiting for time is ready, if so - move them to "Ready" container
        if (nextWaitingJob && moment().diff(nextWaitingJob.nextRunTs) < 0) {
            sch_ClearNext(nextWaitingJob);
            jobStorage.fixJobContainer(nextWaitingJob);
            continue;
        }

        // Pick next jobs ready to run and run them
        for (let i = 0; i < (jobStorage.regularFuncBulk || 1); i++) {
            const job = jobStorage.pickReadyToRun();
            if (!job) {
                if (!jobStorage.closing)
                    jobStorage.my_setTimeout(
                        jobStorage.startRegularFunc,
                        jobStorage.regularFuncMaxTimeout,
                        jobStorage.env,
                        `CODE00000275`,
                        `JobStorage.startRegularFunc`
                    );
                return;
            }
            if (!job.succeded && !job.paused) await runJob(job);
            if (jobStorage.closing) return;
        }
        if (jobStorage.regularFuncMinTimeout) await awaitDelay(jobStorage.regularFuncMinTimeout);
    }
}
