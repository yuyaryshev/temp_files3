import { notificationSetup } from "./notifications";
import { hot } from "react-hot-loader/root";
import React from "react";
import { render } from "react-dom";
import { Main as Main0 } from "./components/main";
import { mainModel, MainModel } from "models";
import { SnackbarProvider, useSnackbar } from "notistack";
import { useObserver } from "mobx-react-lite";
import moment from "moment";
moment.locale("ru");

const useHotReloading = false;

let Main = useHotReloading ? hot(Main0) : Main0;

export const UIMain: React.FC<{ mainModel: MainModel }> = ({ mainModel }) => {
    const { enqueueSnackbar } = useSnackbar();
    notificationSetup(useSnackbar());
    return useObserver(() => <Main m={mainModel} />);
};

(async () => {
    console.log(`Use localStorage.debug = '...' to change debug output!`);
    let root = document.querySelector("#root");
    if (!root) {
        root = document.createElement("div");
        root.id = "root";
        document.body.appendChild(root);
    }

    console.log(`Starting...`);
    console.log(`mainModel = `, mainModel);
    render(
        <SnackbarProvider maxSnack={3}>
            <UIMain mainModel={mainModel} />
        </SnackbarProvider>,
        root
    );
})();

if ((module as any).hot) {
    (module as any).hot.accept();
}
