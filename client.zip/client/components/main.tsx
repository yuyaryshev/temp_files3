import React from "react";
import { toJS } from "mobx";
import { useObserver } from "mobx-react-lite";
import Typography from "@material-ui/core/Typography";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Checkbox from "@material-ui/core/Checkbox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import ReplayIcon from "@material-ui/icons/Replay";
import IconButton from "@material-ui/core/IconButton";
import Button from "@material-ui/core/Button";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import WorkOutlineIcon from "@material-ui/icons/WorkOutline";
import NextWeekIcon from "@material-ui/icons/NextWeek";
import SubjectIcon from "@material-ui/icons/Subject";
import LinearProgress from "@material-ui/core/LinearProgress";
import AssessmentIcon from "@material-ui/icons/Assessment";
import VisibilityIcon from "@material-ui/icons/Visibility";
import PowerSettingsNewIcon from "@material-ui/icons/PowerSettingsNew";
import TextField from "@material-ui/core/TextField";

import debugjs from "debug";
import { StatusIcon } from "./StatusIcon";
import { MainModel } from "../models";

const debugRender = debugjs("render");

const useStyles = makeStyles({
    root: {
        background: "#AAAAAA",
        padding: "16px",
        // margin: "16px"
    },
    runStatusStyles: {
        //        width: "34%",
        overflowX: "auto",
        // padding: "16px",
        // margin: "16px"
    },
    streamsStyles: {
        //        width: "66%",
        overflowX: "auto",
        // padding: "16px",
        // margin: "16px"
    },
    typographyStyles: {
        margin: "16px",
    },
    typographyStylesFooter: {
        margin: "16px",
        width: "100%",
    },
    leftMargin16px: {
        marginLeft: "16px",
    },
    gridControlTestStyle: {
        width: "1300px",
        height: "100%",
    },
    colorPrimary: {
        backgroundColor: "#ff0000",
    },
    barColorPrimary: {
        backgroundColor: "#39b370",
    },
    table: {},
});

export const Main: React.FC<{ m: MainModel }> = ({ m }) => {
    return useObserver(() => {
        const classes = useStyles();
        debugRender("UIRunStatus");

        return (
            <Grid container spacing={3} className={classes.root}>
                <Grid item>
                    <Paper className={classes.runStatusStyles}>
                        <Typography>Lopus ipsum</Typography>
                    </Paper>
                </Grid>
            </Grid>
        );
    });
};

if ((module as any).hot) {
    (module as any).hot.accept();
}

//     @observable knownErrors = [];
