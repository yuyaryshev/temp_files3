import { observable, extendObservable } from "mobx";
import axios from "axios";
import moment from "moment";

export class MainModel {
    @observable instanceName = "???";
    @observable versionStr = "?.?.?";
}

export const mainModel = new MainModel();
(window as any).mainModel = mainModel;
