import { SqliteLog } from "../YsqlLog/SqliteLog";
import { IssueLoaderStatus, makeStatus } from "./IssueLoaderStatus";

import better_sqlite3 from "better-sqlite3";
import deepMerge from "deepmerge";
import { readFileSync } from "fs";
import { resolve } from "path";
import { debugMsgFactory, manageableSetTimeout, manageableTimer, ManageableTimer, yconsole, YConsoleMsg } from "Ystd";
import oracledb from "oracledb";
import {
    dbdDChangelogItemInput,
    dbdDCommentItemInput,
    dbdDJiraFieldInput,
    dbdDLabelInput,
    dbdDLinkItemInput,
    dbdDLinkTypeInput,
    dbdDUserInput,
    dbdDWorklogItemInput,
    dbdJiraIssueInput,
    dbdLoadStreamInput,
    DChangelogItem,
    DCommentItem,
    DJiraField,
    DJiraFieldMarkedMeta,
    DJiraIssue,
    DLabel,
    DLinkItem,
    DLinkType,
    DUser,
    DWorklogItem,
    LoadStream,
    prepareDbDomain,
    PreperedDbDomain,
    readDJiraFieldMarkedMeta,
} from "dbDomains";
import { JiraRequest, JiraRequestHandler, JiraStubInterface, JiraStubOptions, JiraWrapper, makeJiraStub } from "Yjira";
import { ymutex } from "../Ystd/ymutex";
import { Job, JobErrorResolution, jobListLogColumnStr, JobLogItem, JobStorage } from "Yjob";
import { genericLogColumnStr, GenericLogItem } from "./genericLog";
import { allJobContextTypes, allJobTypes } from "job";
import {
    JobContextStatus,
    jobFieldFuncs,
    JobStatus,
    SerializedJob,
    SerializedJobContext,
} from "../job/JobFieldsServer";
import { OracleConnection0 } from "Yoracle";
import { makeOracleBatchWriter, OracleBatchWriter } from "./oracleBatchWriter";

const debug = debugMsgFactory("startup");

export type StartMode = "init" | "deploy" | "run" | "reload" | "drop_all" | "test" | "debugfm";

export interface globalMessagesObj {
    oracle: string;
    sqllite: string;
    jira: string;
}

export interface StartOptions {
    noDbTest?: boolean;
    noJiraTest?: boolean;
    args?: any;
    debugMode?: boolean;
    noBatchMode?: boolean;
}

export interface JiraSettings {
    protocol: string;
    port: number;
    host: string;
    basic_auth: {
        username: string;
        password: string;
    };
    strictSSL?: boolean;
}

export interface OracleSettings {
    user: string;
    password: string;
    connectString: string;
    schema?: string;
}

export interface EnvSettingsTimeouts {
    workCycle: number;
    dbRetry: number;
    jiraIncrFallbackOffset: [number, "years" | "months" | "days" | "hours" | "minutes" | "seconds"];
}

export interface DebugSettings {
    issueKey: string;
    clearCaches: boolean;
}

export interface CacheSettings {
    enabled: boolean;
    file: string;
    minutesToLive: number | undefined;
}

export interface EnvSettings {
    sqlite_stg: string;
    sqlite_history: string;
    sqlite_log: string;
    ignoredJiraFields?: string[];
    jiraMaxResults: number;
    jiraMaxConnections: number;
    jiraMaxConnectionsTimeSpan: number;
    jiraFullLoadBatchSize: number;
    jiraHistDate: string; // Date in iso format
    dbgStream?: string;
    yyadev?: boolean;
    jira: JiraSettings;
    jiradev?: JiraSettings;
    oracle: OracleSettings;
    connect_jira_dev?: boolean;
    tables: TablesSettings;
    stored_procedures: StoredProcedureSettings;
    timeouts: EnvSettingsTimeouts;
    use_stored_procedures?: boolean;
    debug: DebugSettings;
    monitorEndpointPort: number;
    instanceName: string;
    jiraStub?: JiraStubOptions;
}

export interface TablesSettings {
    JIRA_FIELD_T_CHANGES: string;
    JIRA_FIELD_T: string;
    ISSUE_T_CHANGES: string;
    ISSUE_T: string;
    ISSUE_T_OLD: string;
    WORKLOG_T_CHANGES: string;
    WORKLOG_T: string;
    LINK_T_CHANGES: string;
    LINK_T: string;
    LOAD_STREAM_T: string;
    CURRENT_JIRA_FIELD_T: string;
}

export interface StoredProcedureSettings {
    HANDLE_JIRA_FIELD_T_CHANGES: string;
    HANDLE_ISSUE_T_CHANGES: string;
}

export const defaultSettings = (): EnvSettings => ({
    sqlite_stg: "sqlite_stg.db",
    sqlite_history: "sqlite_history.db",
    sqlite_log: "sqlite_log.db",
    instanceName: "<instanceName not set in settings.json>",
    jiraMaxResults: 1000,
    jiraMaxConnections: 10,
    jiraMaxConnectionsTimeSpan: 1000,
    jiraHistDate: "2019-11-19",
    jiraFullLoadBatchSize: 100,
    tables: {
        JIRA_FIELD_T_CHANGES: "JIRA_FIELD_T_CHANGES",
        JIRA_FIELD_T: "JIRA_FIELD_T",
        ISSUE_T_CHANGES: "ISSUE_T_CHANGES",
        ISSUE_T: "ISSUE_T",
        ISSUE_T_OLD: "ISSUES_T_OLD",
        WORKLOG_T_CHANGES: "WORKLOG_T_CHANGES",
        WORKLOG_T: "WORKLOG_T",
        LINK_T_CHANGES: "LINK_T_CHANGES",
        LINK_T: "LINK_T",
        LOAD_STREAM_T: "LOAD_STREAM_T",
        CURRENT_JIRA_FIELD_T: "DONT_TOUCH_JIRA_FIELD_T",
    },
    stored_procedures: {
        HANDLE_JIRA_FIELD_T_CHANGES: "HANDLE_JIRA_FIELD_T_CHANGES",
        HANDLE_ISSUE_T_CHANGES: "HANDLE_ISSUE_T_CHANGES",
    },
    jira: {
        protocol: "http",
        port: 80,
        host: "jira.moscow.alfaintra.net",
        basic_auth: {
            username: "username",
            password: "password",
        },
        strictSSL: false,
    },
    oracle: {
        user: "username",
        password: "password",
        connectString: "DWSTPROD_TAF",
    },
    timeouts: {
        workCycle: 10000,
        dbRetry: 10000,
        jiraIncrFallbackOffset: [10, "minutes"],
    },
    debug: {
        issueKey: "",
        clearCaches: false,
    },
    monitorEndpointPort: 29354,
});

export type DbProviderCallback<T> = (db: OracleConnection0) => Promise<T>;

export interface Env {
    terminating: boolean;
    onTerminateCallbacks: (() => void)[];
    versionStr: string;
    args: any;
    startMode: StartMode;
    settings: EnvSettings;
    jira: JiraWrapper;
    dbProvider: <T>(callback: (db: OracleConnection0) => Promise<T>) => Promise<T>;

    dbdDChangelogItem: PreperedDbDomain<DChangelogItem>;
    dbdDCommentItem: PreperedDbDomain<DCommentItem>;
    dbdDJiraField: PreperedDbDomain<DJiraField>;
    // dbdJiraIssue
    dbdDLabel: PreperedDbDomain<DLabel>;
    dbdDLinkItem: PreperedDbDomain<DLinkItem>;
    dbdLoadStream: PreperedDbDomain<LoadStream>;
    dbdDUser: PreperedDbDomain<DUser>;
    dbdDWorklogItem: PreperedDbDomain<DWorklogItem>;
    dbdDLinkType: PreperedDbDomain<DLinkType>;

    status: IssueLoaderStatus;
    jobLog: SqliteLog<JobLogItem>;
    genericLog: SqliteLog<GenericLogItem>;
    jobStorage: JobStorage<
        EnvWithDbdJiraIssue, // TEnv
        SerializedJobContext, // TSerializedJobContext extends DefaultSerializedJobContext = DefaultSerializedJobContext,
        JobContextStatus, // TJobContextStatus extends DefaultJobContextStatus = DefaultJobContextStatus
        SerializedJob, // TSerializedJob extends DefaultSerializedJob = DefaultSerializedJob,
        JobStatus // TJobStatus extends DefaultJobStatus = DefaultJobStatus,
    >;
    globalMessages: globalMessagesObj;
    debugMode?: boolean;
    timers: Set<ManageableTimer>;
    terminate: () => void | Promise<void>;
    noBatchMode?: boolean;
    oracleBatchWriter: OracleBatchWriter;
    useOracleBatch_REMOVE_THIS_WHEN_DEBUGGED?: boolean;
}

export interface EnvWithDbdJiraIssue extends Env {
    dbdJiraIssue: PreperedDbDomain<DJiraIssue>;
}

export interface IssueLoaderVersion {
    major?: number;
    minor?: number;
    build?: number;
}

export const startEnv = async (startMode: StartMode, startOptions: StartOptions = {}): Promise<Env> => {
    const pthis = ({
        onTerminateCallbacks: [],
        terminating: false,
        timers: new Set(),
        terminate: () => {
            for (let callback of pthis.onTerminateCallbacks) callback();
            pthis.terminating = true;
            for (let timer of pthis.timers) timer.cancel();
        },
        useOracleBatch_REMOVE_THIS_WHEN_DEBUGGED: true,
    } as any) as Env;
    const { args, noDbTest, noJiraTest, debugMode, noBatchMode } = startOptions;
    delete startOptions.args;

    yconsole.log(
        `CODE00000094`,
        `Starting issue_loader, mode = ${startMode}, startOptions = ${JSON.stringify(startOptions)}...`
    );
    const settingsPath = resolve("./settings.json");
    yconsole.log(`CODE00000197`, `settingsPath = ${settingsPath}`);

    const settings = deepMerge(defaultSettings(), JSON.parse(readFileSync(settingsPath, "utf-8")));
    if (settings.monitorEndpointPort)
        yconsole.log(`CODE00000198`, `Monitoring on port ${settings.monitorEndpointPort}`);

    const status = makeStatus();
    const better_sqlite3_log = better_sqlite3(settings.sqlite_log);
    const jobLog = new SqliteLog<JobLogItem>(better_sqlite3_log, jobListLogColumnStr, { table: "job_log" });
    const genericLog = new SqliteLog<GenericLogItem>(better_sqlite3_log, genericLogColumnStr, { table: "generic_log" });

    const better_sqlite3_db = better_sqlite3(settings.sqlite_stg);
    const better_sqlite3_db_history = settings.sqlite_history ? better_sqlite3(settings.sqlite_history) : undefined;

    let v: IssueLoaderVersion = {};
    try {
        v = JSON.parse(readFileSync("version.json", "utf-8"));
    } catch (e) {
        if (e.code !== "ENOENT") throw e;
    }
    const versionStr = `${v.major || 0}.${v.minor || 0}.${v.build || 0}`;
    yconsole.log(`CODE00000199`, `version = ${versionStr}`);

    debug(`CODE00000306`, `Load settings - finished`);

    debug(`CODE00000307`, `Initializing database domains`);

    const dbdDJiraField = prepareDbDomain(settings, dbdDJiraFieldInput);
    const dbdLoadStream = prepareDbDomain(settings, dbdLoadStreamInput);
    const dbdDCommentItem = prepareDbDomain(settings, dbdDCommentItemInput);
    const dbdDChangelogItem = prepareDbDomain(settings, dbdDChangelogItemInput);
    const dbdDUser = prepareDbDomain(settings, dbdDUserInput);
    const dbdDLabel = prepareDbDomain(settings, dbdDLabelInput);
    const dbdDWorklogItem = prepareDbDomain(settings, dbdDWorklogItemInput);
    const dbdDLinkItem = prepareDbDomain(settings, dbdDLinkItemInput);
    const dbdDLinkType = prepareDbDomain(settings, dbdDLinkTypeInput);

    debug(`CODE00000308`, `dbdDJiraField - OK`);

    if (!noJiraTest)
        yconsole.log(
            `CODE00000309`,
            `Testing Jira connection with '${settings.jira.protocol}' to '${settings.jira.host}:${settings.jira.port}'...`
        );

    function jiraStubHandler(key: string, jiraRequest: JiraRequest, stubGet?: JiraRequestHandler): any {
        // if (jiraRequest.jiraApiPath === "search.search" && jiraRequest.opts.jql.includes("updated"))
        //     return `"{"expand":"schema,names","startAt":0,"maxResults":50,"total":0,"issues":[]}"`;
        return stubGet!(key, jiraRequest);
    }

    let jiraStub: JiraStubInterface | undefined;
    if (settings.jiraStub) {
        if (settings.jiraStub.filename) settings.jiraStub.filename = resolve(settings.jiraStub.filename!);
        jiraStub = makeJiraStub({
            ...settings.jiraStub,
            console: yconsole,
            env: pthis,
            handler: jiraStubHandler,
            errorStateChanged: sqliteErrorStateChanged,
        });
    }

    const jira = new JiraWrapper({
        ...settings,
        jiraStub,
        credentials: settings.jira,
        console: yconsole,
    });

    if (!noJiraTest) {
        const serverInfo = await jira.getServerInfo();
        if (!serverInfo || !serverInfo.version)
            yconsole.error(`CODE00000310`, `Couldn't connect to Jira. Will retry later...`);
        else yconsole.log(`CODE00000311`, `Connected to Jira v${serverInfo.version} - OK`);
    }

    const dbMutex = ymutex();
    const dbProvider = async function<T>(callback: DbProviderCallback<T>) {
        return dbMutex.lock(async function() {
            oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
            const db = ((await oracledb.getConnection(settings.oracle)) as any) as OracleConnection0;
            await db.execute(`alter session set NLS_TIME_FORMAT='HH24:MI:SSXFF'`);
            await db.execute(`alter session set NLS_TIMESTAMP_FORMAT='YYYY-MM-DD"T"hh24:mi:ss.ff'`);
            await db.execute(`alter session set NLS_TIME_TZ_FORMAT='HH24:MI:SSXFF TZR'`);
            await db.execute(`alter session set NLS_TIMESTAMP_TZ_FORMAT='YYYY-MM-DD"T"hh24:mi:ss.ffTZHTZM'`);
            if (settings.oracle.schema) await db.execute(`ALTER SESSION SET CURRENT_SCHEMA=${settings.oracle.schema}`);

            const r = await callback(db);
            await db.close();
            return r;
        });
    };

    if (!noDbTest) {
        yconsole.log(`CODE00000110`, `Testing Oracle connection '${settings.oracle.connectString}'...`);
        const oracleVersion = await dbProvider(async function(db: OracleConnection0) {
            const r = await db.execute(
                `SELECT * from v$version`,
                [] // bind value for :id
            );
            // @ts-ignore
            return Object.values(r.rows[0])[0];
        });
        if (!oracleVersion || !oracleVersion.length)
            yconsole.error(`CODE00000111`, `Couldn't connect to Oracle. Will retry later...`);
        else yconsole.log(`CODE00000112`, `Connected to Oracle '${oracleVersion}' - OK`);
    }

    function sqliteErrorStateChanged(error: Error | undefined) {
        // void | Promise<void>
        // TODO env.globalMessages.sqlite = { status: (!error ? "OK" : "Error"), error };
    }

    const jobStorage = new JobStorage<
        EnvWithDbdJiraIssue, // TEnv
        SerializedJobContext, // TSerializedJobContext extends DefaultSerializedJobContext = DefaultSerializedJobContext,
        JobContextStatus, // TJobContextStatus extends DefaultJobContextStatus = DefaultJobContextStatus
        SerializedJob, // TSerializedJob extends DefaultSerializedJob = DefaultSerializedJob,
        JobStatus // TJobStatus extends DefaultJobStatus = DefaultJobStatus,
    >({
        env: pthis as any,
        db: better_sqlite3_db,
        historyDb: better_sqlite3_db_history,
        allJobTypes,
        allJobContextTypes,
        autoStartRegularFunc: false,
        noBatchMode: noBatchMode,
        console: yconsole,
        setTimeout: manageableSetTimeout,
        jobFieldFuncs,
        errorStateChanged: sqliteErrorStateChanged,
        jobResourcesLimits: {
            jira: 50,
            cpu: 30,
            db: 100,
        },
        onJobError: (job: Job, errorMessage: string): JobErrorResolution | undefined => {
            if (errorMessage.includes("ORA-00001"))
                // Unique constraint violation
                return { persistentError: true };
            return undefined;
        },
    });

    const deleteOldLogs = () => {
        try {
            try {
                genericLog.deleteOld();
            } catch (e) {
                yconsole.error(`CODE00000103`, `Couldn't delete old logs because of error: ${e.message}`);
            }
            try {
                jobLog.deleteOld();
            } catch (e) {
                yconsole.error(`CODE00000104`, `Couldn't delete old logs because of error: ${e.message}`);
            }
        } finally {
            manageableTimer(pthis, 4 * 60 * 60 * 1000, "CODE00000318", "deleteOldLogs", deleteOldLogs);
        }
    };
    if (startMode === "run") deleteOldLogs();

    (global as any).logger = (m: YConsoleMsg) => {
        genericLog.add(Object.assign({}, m, { data: m.data && m.data.length ? JSON.stringify(m.data) : "" }));
        return true;
    };

    const globalMessages = { oracle: "ok", sqllite: "ok", jira: "ok" };

    function oracleErrorStateChanged(error: Error | undefined) {
        // void | Promise<void>
        // TODO env.globalMessages.oracle = { status: (!error ? "OK" : "Error"), error };
    }

    const oracleBatchWriter = makeOracleBatchWriter({
        env: pthis as any,
        errorStateChanged: oracleErrorStateChanged,
    });

    debug(`CODE00000098`, `starting jobStorage.startRegularFunc`);
    if (startMode === "run" && !debugMode) jobStorage.startRegularFunc();

    debug(`CODE00000101`, `startEnv - finished`);

    return Object.assign(pthis, {
        terminating: false,
        versionStr,
        args,
        startMode,
        settings,
        jira,
        dbProvider,
        dbdDJiraField,
        dbdLoadStream,
        dbdDCommentItem,
        dbdDChangelogItem,
        dbdDUser,
        dbdDLabel,
        dbdDWorklogItem,
        dbdDLinkItem,
        dbdDLinkType,
        status,
        jobLog,
        genericLog,
        jobStorage,
        globalMessages,
        debugMode,
        noBatchMode,
        oracleBatchWriter,
    } as Env);
};

export async function loadDbdIssueFields(env: Env, current: boolean = true): Promise<EnvWithDbdJiraIssue> {
    const table = current ? env.settings.tables.CURRENT_JIRA_FIELD_T : env.settings.tables.JIRA_FIELD_T;
    yconsole.log(`CODE00000114`, `Loading fields meta from '${table}'...`);

    let markedFields: DJiraFieldMarkedMeta[] = [];
    const dbdJiraIssue = await env.dbProvider(async function(db: OracleConnection0) {
        markedFields = await readDJiraFieldMarkedMeta(db, table, false);
        // yconsole.log("markedFields = \n", dbgStringify(markedFields));
        return prepareDbDomain(env.settings, dbdJiraIssueInput(markedFields));
    });

    yconsole.log(`CODE00000115`, `Loading fields meta - OK`);
    return Object.assign(env, { dbdJiraIssue }) as EnvWithDbdJiraIssue;
}
