import { Env } from "other";
import moment from "moment";
import { debugMsgFactory as debugjs } from "Ystd";

const debug = debugjs("jobStatusApi");

// http://a123278.moscow.alfaintra.net:29364/api/status
export const statusApi = async (env: Env, req: any, res: any) => {
    const ts = moment().format();
    let error: string | undefined = undefined;
    let ok: boolean = false;
    const { query } = req;
    const fullRefresh = !query.ts || moment().diff(query.ts) > env.jobStorage.statusTTL;
    const jiraStats = env.jira.responseStats().total;

    let jiraStatus = {
        jiraRequestsPerSecond: jiraStats.c, /// Запросов к Jira в секунду
        JiraResposeErrorsCount: jiraStats.errorsCount, /// Количество ошибок к Jira в ответах
        JiraResponseAverageTime: jiraStats.avgMs, /// Среднее время отклика JIra
    };

    return res.send(
        JSON.stringify({
            ok,
            error,
            ts,
            fullRefresh,
            instanceName: env.settings.instanceName,
            versionStr: env.versionStr,
            globalMessages: env.globalMessages,
            jiraStatus: jiraStatus,
            resurses: {
                Jira: (env.jobStorage.jobResourcesCurrent.jira / env.jobStorage.jobResourcesLimits.jira) * 100,
                DB: (env.jobStorage.jobResourcesCurrent.db / env.jobStorage.jobResourcesLimits.db) * 100,
                CPU: (env.jobStorage.jobResourcesCurrent.cpu / env.jobStorage.jobResourcesLimits.cpu) * 100,
            },
        })
    );
};
