import { Env } from "other";
import moment from "moment";
import { debugMsgFactory as debugjs, manageableTimer } from "Ystd";
import { JobContext } from "Yjob/JobContext";

const debug = debugjs("issueStatsApi");
let started = false;

// project, jobType, status, jobsCount, issuesCount, minTs, maxTs
export interface IssueLoaderStatItem {
    project: string;
    stage: string;
    issueCount: number;
}

let issueStats: IssueLoaderStatItem[] = [];

// http://a123278.moscow.alfaintra.net:29364/api/stats

let refreshTimer: any = undefined;

export async function issueStatsApi(env: Env, req: any, res: any) {
    // @ts-ignore
    const pthis = this;

    const ts = moment().format();
    let error: string | undefined = undefined;
    let ok: boolean = false;
    const { query } = req;

    try {
        if (!refreshTimer)
            refreshTimer = manageableTimer(env, 300, `CODE00000125`, "issueStatsRefreshTimer", () => {
                issueStats = env.jobStorage.db.prepare(`select project, stage, count(1) issueCount from mem.all_job group by project, stage`).all();

                // let newStats = new Map<string, IssueLoaderStatItem>();
                //
                // let ids: string[] = [];
                // env.jobStorage.iterateJobContexts(undefined, (jobContext: JobContext) => {
                //     ids.push(jobContext.id);
                //     let k = `${(jobContext as any).project}, ${jobContext.stage}`;
                //     let s = newStats.get(k);
                //
                //     if (!s) {
                //         newStats.set(
                //             k,
                //             (s = {
                //                 project: (jobContext as any).project,
                //                 stage: jobContext.stage,
                //                 issueCount: 0,
                //             } as IssueLoaderStatItem)
                //         );
                //     }
                //     s.issueCount++;
                // });
                //
                // issueStats = [...newStats.values()];
            });
        refreshTimer.setTimeout();
    } catch (e) {
        error = e.message;
        if (env.debugMode) debug(`CODE00000097 statsApi for ts=${query.ts} - ERROR!`, e);
    }

    return res.send(
        JSON.stringify({
            ok,
            error,
            ts,
            stats: issueStats,
        })
    );
}
