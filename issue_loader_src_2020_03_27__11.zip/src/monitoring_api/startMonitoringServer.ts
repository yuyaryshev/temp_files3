import { Env } from "other";
import { yconsole } from "Ystd";
import express from "express";

import { statusApi } from "./statusApi";
import { issuesApi } from "./issuesApi";
import { jobsApi } from "./jobsApi";
import { logsApi } from "./logsApi";
import { issueStatsApi } from "./issueStatsApi";
import { jobStatsApi } from "./jobStatsApi";
import { jobPauseApi } from "./jobPauseApi";
import { jobResumeApi } from "./jobResumeApi";
import { jobMakeStaleApi } from "./jobMakeStaleApi";

export function startMonitoring(env: Env, port: number | undefined) {
    if (!port) {
        console.log(
            `CODE00000183`,
            `No monitoring port specified. /runStatus and /api/runStatus monitor endpoint is disabled in settings file.`
        );
        yconsole.log(
            `CODE00000225`,
            `No monitoring port specified. /runStatus and /api/runStatus monitor endpoint is disabled in settings file.`
        );
        return;
    }

    const app = express();
    app.use(function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
    });

    app.get("/api/status", (req, res) => statusApi(env, req, res));

    app.get("/api/issues", (req, res) => issuesApi(env, req, res));
    app.get("/api/jobs", (req, res) => jobsApi(env, req, res));
    app.get("/api/logs", (req, res) => logsApi(env, req, res));
    app.get("/api/issuestats", (req, res) => issueStatsApi(env, req, res));
    app.get("/api/jobstats", (req, res) => jobStatsApi(env, req, res));
    app.get("/api/jobPause", (req, res) => jobPauseApi(env, req, res));
    app.get("/api/jobResume", (req, res) => jobResumeApi(env, req, res));
    app.get("/api/jobMakeStale", (req, res) => jobMakeStaleApi(env, req, res));

    app.use(express.static("public"));
    app.listen(port, () => {
        console.log(`CODE00000282`, `Started /runStatus and /api/runStatus monitor endpoint on port ${port}...`);
        yconsole.log(`CODE00000283`, `Started /runStatus and /api/runStatus monitor endpoint on port ${port}...`);
    });

    env.onTerminateCallbacks.push(() => {
        (app as any).close();
    });
}
