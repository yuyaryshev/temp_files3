export function dummyFunc1(a: number, b: number) {
    return a + b;
}
