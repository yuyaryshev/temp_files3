import { useObserver } from "mobx-react-lite";
import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import TableCell from "@material-ui/core/TableCell";
import TableRow from "@material-ui/core/TableRow";
import { ProgressBar } from "./RC_ProgressBar";
import debugjs from "debug";
import { GlobalUIState } from "./RunStatus";

const debugRender = debugjs("render");

const useStyles = makeStyles({
    table: {
        minWidth: 650,
    },
    typographyStylesFooter: {
        margin: "16px",
        width: "100%",
    },
    stepColumn: {
        width: "20px",
    },
});

const allFields = true;

export const UIIssueStatsRow: React.FC<{ data: any; globalUIState: GlobalUIState }> = ({ data, globalUIState }) => {
    debugRender("UIIssueStatsRow");
    // react-native-multicolor-progress-bar
    const classes = useStyles();

    return useObserver(() => (
        <TableRow className={classes.table}>
            {globalUIState.issue_stats_checkProjects && !globalUIState.issue_stats_checkAll ? (
                <>
                    <TableCell>{data.project}</TableCell>
                </>
            ) : (
                undefined
            )}
            <TableCell>
                <ProgressBar data={data.Pprogress} />
            </TableCell>
            <TableCell>{data.onJira}</TableCell>
            <TableCell>{data.onTransform}</TableCell>
            <TableCell>{data.onDB}</TableCell>
            <TableCell>{data.succeded}</TableCell>
            <TableCell>{data.total}</TableCell>
        </TableRow>
    ));
};

if ((module as any).hot) {
    (module as any).hot.accept();
}
