import { useObserver } from "mobx-react-lite";
import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import debugjs from "debug";
// @ts-ignore
import { Animated, View } from "react-native-web";

const debugRender = debugjs("render");

const useStyles = makeStyles({
    table: {
        minWidth: 650,
    },
    typographyStylesFooter: {
        margin: "16px",
        width: "100%",
    },
    stepColumn: {
        width: "200px",
    },
});

// Error:(5, 40) TS7016: Could not find a declaration file for module 'react-native-web'. 'D:/GIT_PROJECTS/issue_loader76/node_modules/.pnpm/mvn/react-native-web/0.12.2_react-dom@16.12.0+react@16.12.0/node_modules/react-native-web/dist/cjs/index.js' implicitly has an 'any' type.
//   Try `pnpm install @types/react-native-web` if it exists or add a new declaration (.d.ts) file containing `declare module 'react-native-web';`

function BarCalculate(DataResult: any, maxLenght: any) {
    let currLenght = 0;

    DataResult.forEach(function(i: any, item: any) {
        currLenght += i.progress;
    });

    let barCoefficient = currLenght > 0 ? maxLenght / currLenght : 1;

    // сортируем по цвету
    DataResult.sort(function(o1: any, o2: any) {
        return o2.color.orderColor > o1.color.orderColor ? 1 : -1;
    });

    DataResult.forEach(function(i: any, item: any) {
        i.progress = i.progress * barCoefficient;
    });

    currLenght = maxLenght;
    let localLen;
    if (DataResult.length > 1) {
        for (let i = 0; i < DataResult.length; i++) {
            localLen = DataResult[i].progress;
            DataResult[i].progress = currLenght;
            currLenght = currLenght - localLen;
        }
    }

    return DataResult;
}

export const ProgressBar: React.FC<{ data: any }> = ({ data }) => {
    debugRender("TestProgressBar");

    let barHeight = 8;
    let maxLenght = 100;
    let DataResult = Object.assign(data);

    DataResult = BarCalculate(DataResult, maxLenght);

    return useObserver(() => (
        <View
            style={{
                position: "relative",
                marginTop: 16,
                marginBottom: 16 + (barHeight || 8),
                width: "100%",
            }}
        >
            {DataResult.map((d: any, i: any) => {
                return (
                    <Animated.View
                        key={i}
                        style={{
                            position: "absolute",
                            height: barHeight || 8,
                            width: `${d.progress}%`,
                            backgroundColor: d.color.rgb,
                            borderRadius: 5,
                        }}
                    />
                );
            })}
        </View>
    ));
};

if ((module as any).hot) {
    (module as any).hot.accept();
}
