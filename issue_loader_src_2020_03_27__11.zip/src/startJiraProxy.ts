import { jiraProxy } from "./jiraProxy";

jiraProxy();
