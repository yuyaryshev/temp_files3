import { awaitDelay, yconsole } from "Ystd";
import { issuesToJobs } from "../entry_scripts/run_scanForChangedIssueIds";
import { GenericTestEnv, makeTestEnv } from "./global_tests_env.test";

describe(`global_tests`, function() {
    xit(`DATAMAP_5_issues - 01 CODE00000096`, async function() {
        try {
            // Jest doesn't know  this.timeout
            this.timeout(2000000000);
        } catch (e) {}
        let env: GenericTestEnv = undefined as any;

        try {
            const jql = `project = DATAMAP and issuekey < DATAMAP-6`;
            env = await makeTestEnv({ testName: "DATAMAP_5_issues" });

            const issueContextInputs = await env.jira.jqlGetIssueIds(jql);
            await issuesToJobs(env as any, issueContextInputs);

            await awaitDelay(300);
            while (env.jobStorage.nonSuccededJobsCount()) await awaitDelay(10);
            await awaitDelay(100);
            while (env.jobStorage.nonSuccededJobsCount()) await awaitDelay(10);
            await awaitDelay(100);
            while (env.jobStorage.nonSuccededJobsCount()) await awaitDelay(10);

            yconsole.log("CODE00000105", `${env.testName}- TEST FINISHED!`);
            // TODO добавить проверку того что в итоге загрузилось.
        } finally {
            if (env) env.terminate();
        }
        // OK if no exceptions thrown
    });

    xit(`DATAMAP_full - 01 CODE00000106`, async function() {
        try {
            // Jest doesn't know this.timeout
            this.timeout(2000000000);
        } catch (e) {}

        let env: GenericTestEnv = undefined as any;

        try {
            const jql = `project = DATAMAP`;
            env = await makeTestEnv({ testName: "DATAMAP_full" });

            const issueContextInputs = await env.jira.jqlGetIssueIds(jql);
            await issuesToJobs(env as any, issueContextInputs);

            await awaitDelay(300);
            while (env.jobStorage.nonSuccededJobsCount()) await awaitDelay(10);
            await awaitDelay(100);
            while (env.jobStorage.nonSuccededJobsCount()) await awaitDelay(10);
            await awaitDelay(100);
            while (env.jobStorage.nonSuccededJobsCount()) await awaitDelay(10);

            yconsole.log("CODE00000107", `${env.testName}- TEST FINISHED!`);
            // TODO добавить проверку того что в итоге загрузилось.
        } finally {
            if (env) env.terminate();
        }
        // OK if no exceptions thrown
    });
});
