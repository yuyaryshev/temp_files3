export interface JobResources {
    [key: string]: number;
}

export function JobResourcesCheck(storage: JobResources, job: JobResources) {
    for (let k in job) {
        if (job[k] > (storage[k] || 0)) return false;
    }
    return true;
}

export function JobResourcesIsEmpty(resources: JobResources) {
    for (let k in resources) if (resources[k] > 0) return false;
    return true;
}

export function JobResourcesAlloc(storage: JobResources, job: JobResources) {
    for (let k in job) storage[k] = (storage[k] || 0) - job[k];
}

export function JobResourcesCheckAndAlloc(storage: JobResources, job: JobResources) {
    const r = JobResourcesCheck(storage, job);
    if (!r) return false;
    JobResourcesAlloc(storage, job);
    return true;
}

export function JobResourcesRelease(storage: JobResources, job: JobResources) {
    for (let k in job) storage[k] = (storage[k] || 0) + job[k];
}
