import { Job } from "./Job";
import { JobFieldFuncs, JobStorage } from "./JobStorage";
import { JobContext } from "./JobContext";
import { JobState } from "Yjob/JobState";
import { EnvWithTimers } from "Ystd";

import moment from "moment";
// @ts-ignore
require("moment-countdown");

export const defaultJobFieldFuncs: JobFieldFuncs<DefaultSerializedJobContext, DefaultJobContextStatus> = {
    jobContextColumnStr:
        "id, key, jobsById, priority, predecessorsDone, createdTs, finishedTs, jobContextType, succeded, startedTs, prevError, retryIntervalIndex, nextRunTs, input, paused, timesSaved, state, stage",
    jobContextColumnPlaceholderStr: "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?",
    jobContextMemColumnStr:
        "id, key, priority, predecessorsDone, createdTs, finishedTs, jobContextType, succeded, startedTs, prevError, retryIntervalIndex, nextRunTs, paused, timesSaved, updatedTs, state, stage",
    jobContextMemColumnPlaceholderStr: "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?",

    serializeStatus: function serializeStatus(j: JobContext): DefaultJobContextStatus {
        const input = j.input;

        const jobsById = {} as DefaultSerializedJobs;
        for (let jobId in j.jobsById) {
            const sj = j.jobsById[jobId];
            jobsById[jobId] = {
                jobType: sj.jobType.type,
                id: sj.id,
                key: sj.key,
                priority: sj.priority,
                cancelled: sj.cancelled ? 1 : 0,
                predecessorsDone: sj.predecessorsDone ? 1 : 0,
                createdTs: sj.createdTs.format(),
                finishedTs: sj.finishedTs ? sj.finishedTs.format() : undefined,
                succeded: sj.succeded ? 1 : 0,
                startedTs: sj.startedTs ? sj.startedTs.format() : undefined,
                prevError: sj.prevError,
                retryIntervalIndex: sj.retryIntervalIndex,
                nextRunTs: sj.nextRunTs ? sj.nextRunTs.format() : undefined,
                input: JSON.stringify(sj.input),
                prevResult: JSON.stringify(sj.prevResult),
                paused: sj.paused ? 1 : 0,
                state: sj.state,
            };
        }

        return {
            deleted: 0,
            updatedTs: moment().format(),
            jobsById: JSON.stringify(jobsById),
            jobContextType: j.jobContextType.type,
            id: j.id,
            key: j.key,
            priority: j.priority,
            predecessorsDone: j.predecessorsDone ? 1 : 0,
            createdTs: j.createdTs.format(),
            finishedTs: j.finishedTs ? j.finishedTs.format() : undefined,
            succeded: j.succeded ? 1 : 0,
            startedTs: j.startedTs ? j.startedTs.format() : undefined,
            prevError: j.prevError,
            retryIntervalIndex: j.retryIntervalIndex,
            nextRunTs: j.nextRunTs ? j.nextRunTs.format() : undefined,
            input: JSON.stringify(input),
            paused: j.paused ? 1 : 0,
            timesSaved: j.timesSaved,
            state: j.state,
            stage: j.stage,
        };
    },
    serialize: function serialize(j: JobContext): DefaultSerializedJobContext {
        const input = j.input;

        const jobsById = {} as DefaultSerializedJobs;
        for (let jobId in j.jobsById) {
            const sj = j.jobsById[jobId];
            jobsById[jobId] = {
                jobType: sj.jobType.type,
                id: sj.id,
                key: sj.key,
                priority: sj.priority,
                cancelled: sj.cancelled ? 1 : 0,
                predecessorsDone: sj.predecessorsDone ? 1 : 0,
                createdTs: sj.createdTs.format(),
                finishedTs: sj.finishedTs ? sj.finishedTs.format() : undefined,
                succeded: sj.succeded ? 1 : 0,
                startedTs: sj.startedTs ? sj.startedTs.format() : undefined,
                prevError: sj.prevError,
                retryIntervalIndex: sj.retryIntervalIndex,
                nextRunTs: sj.nextRunTs ? sj.nextRunTs.format() : undefined,
                input: JSON.stringify(sj.input),
                prevResult: JSON.stringify(sj.prevResult),
                paused: sj.paused ? 1 : 0,
                state: sj.state,
            };
        }

        return {
            updatedTs: moment().format(),
            jobsById: JSON.stringify(jobsById),
            jobContextType: j.jobContextType.type,
            id: j.id,
            key: j.key,
            priority: j.priority,
            predecessorsDone: j.predecessorsDone ? 1 : 0,
            createdTs: j.createdTs.format(),
            finishedTs: j.finishedTs ? j.finishedTs.format() : undefined,
            succeded: j.succeded ? 1 : 0,
            startedTs: j.startedTs ? j.startedTs.format() : undefined,
            prevError: j.prevError,
            retryIntervalIndex: j.retryIntervalIndex,
            nextRunTs: j.nextRunTs ? j.nextRunTs.format() : undefined,
            input: JSON.stringify(input),
            paused: j.paused ? 1 : 0,
            timesSaved: j.timesSaved,
            state: j.state,
            stage: j.stage,
        };
    },
    serializeMem: function serializeMem(j: JobContext): DefaultSerializedJobContextMem {
        const input = j.input;

        return {
            updatedTs: moment().format(),

            jobContextType: j.jobContextType.type,
            id: j.id,
            key: j.key,
            priority: j.priority,
            predecessorsDone: j.predecessorsDone ? 1 : 0,
            createdTs: j.createdTs.format(),
            finishedTs: j.finishedTs ? j.finishedTs.format() : undefined,
            succeded: j.succeded ? 1 : 0,
            startedTs: j.startedTs ? j.startedTs.format() : undefined,
            prevError: j.prevError,
            retryIntervalIndex: j.retryIntervalIndex,
            nextRunTs: j.nextRunTs ? j.nextRunTs.format() : undefined,
            paused: j.paused ? 1 : 0,
            timesSaved: j.timesSaved,
            state: j.state,
            stage: j.stage,
        };
    },
    serializeToArray: function serializedToArray(o: DefaultSerializedJobContext) {
        return [
            o.id,
            o.key,
            o.jobsById,
            o.priority,
            o.predecessorsDone,
            o.createdTs,
            o.finishedTs,
            o.jobContextType,
            o.succeded,
            o.startedTs,
            o.prevError,
            o.retryIntervalIndex,
            o.nextRunTs,
            o.input,
            o.paused,
            o.timesSaved,
            o.state,
            o.stage,
        ];
    },

    serializeMemToArray: function serializedMemToArray(o: DefaultSerializedJobContextMem) {
        return [
            o.id,
            o.key,
            o.priority,
            o.predecessorsDone,
            o.createdTs,
            o.finishedTs,
            o.jobContextType,
            o.succeded,
            o.startedTs,
            o.prevError,
            o.retryIntervalIndex,
            o.nextRunTs,
            o.paused,
            o.timesSaved,
            o.updatedTs,
            o.state,
            o.stage,
        ];
    },

    rowToSerialized: function rowToSerialized(row: any): DefaultSerializedJobContext {
        for (let k in row) if (row[k] === null) delete row[k];
        const serialized: DefaultSerializedJobContext = row;
        serialized.input = serialized.input ? JSON.parse(serialized.input) : {};
        serialized.jobsById = serialized.jobsById ? JSON.parse(serialized.jobsById) : {};

        return serialized;
    },

    deserialize: function deserialize<TEnv extends EnvWithTimers>(
        jobStorage: JobStorage<TEnv, DefaultSerializedJobContext, DefaultJobContextStatus, DefaultSerializedJob, DefaultJobStatus>,
        serialized: DefaultSerializedJobContext,
    ): JobContext {
        const jobContextType = jobStorage.allJobContextTypes[serialized.jobContextType];
        if (!jobContextType) throw new Error(`CODE00000000 jobContextType=${serialized.jobContextType} - not found!`);

        const r = new JobContext<any, any, any, any, any, any>(jobContextType, jobStorage, serialized.input, serialized.id, serialized.key);

        r.priority = serialized.priority;
        r.predecessorsDone = !!serialized.predecessorsDone;
        r.createdTs = moment(serialized.createdTs);
        r.finishedTs = serialized.finishedTs ? moment(serialized.finishedTs) : undefined;
        r.succeded = !!serialized.succeded;
        r.startedTs = serialized.startedTs ? moment(serialized.startedTs) : undefined;
        r.prevError = serialized.prevError;
        r.retryIntervalIndex = serialized.retryIntervalIndex;
        r.nextRunTs = serialized.nextRunTs ? moment(serialized.nextRunTs) : undefined;
        r.paused = !!serialized.paused;
        r.timesSaved = serialized.timesSaved;
        r.state = serialized.state;
        r.stage = serialized.stage;

        r.jobsById = {} as any;
        for (let jobId in serialized.jobsById) {
            const serializedJob = serialized.jobsById[jobId];

            const jobType = jobStorage.allJobTypes[serializedJob.jobType];
            if (!jobType) throw new Error(`CODE00000000 jobType=${serializedJob.jobType} - not found!`);

            const jr = new Job(jobType, r, serializedJob.input, serializedJob.id, serializedJob.key, serializedJob.parent);

            jr.priority = serializedJob.priority;
            jr.cancelled = !!serializedJob.cancelled;
            jr.predecessorsDone = !!serializedJob.predecessorsDone;
            jr.createdTs = moment(serializedJob.createdTs);
            jr.finishedTs = serializedJob.finishedTs ? moment(serializedJob.finishedTs) : undefined;
            jr.succeded = !!serializedJob.succeded;
            jr.startedTs = serializedJob.startedTs ? moment(serializedJob.startedTs) : undefined;
            jr.prevError = serializedJob.prevError;
            jr.retryIntervalIndex = serializedJob.retryIntervalIndex;
            jr.nextRunTs = serializedJob.nextRunTs ? moment(serializedJob.nextRunTs) : undefined;
            jr.prevResult = serializedJob.prevResult && JSON.parse(serializedJob.prevResult);
            jr.paused = !!serializedJob.paused;
            jr.state = serializedJob.state;

            r.jobsById[jobId] = jr;
            //r.jobsByKey[jr.key] = jr;
        }
        return r;
    },
};

/* Client class declaraion
export class JobStatus {
    @observable id: string="" as any;
    @observable key: string="" as any;
    @observable priority: number | undefined=0;
    @observable cancelled: number=0;
    @observable predecessorsDone: number=0;
    @observable createdTs: string="";
    @observable finishedTs: string | undefined="";
    @observable jobType: string="";
    @observable succeded: number=0;
    @observable startedTs: string | undefined="";
    @observable prevError: string | undefined="" as any;
    @observable retryIntervalIndex: number=0;
    @observable nextRunTs: string | undefined="";
    @observable input: any=undefined;
    @observable prevResult: any | undefined=undefined;
    @observable paused: number=0;
    @observable state: JobState="" as any;
};

export class JobContextStatus {
    @observable id: string="" as any;
    @observable key: string="" as any;
    @observable jobsById: any={};
    @observable priority: number | undefined=0;
    @observable predecessorsDone: number=0;
    @observable createdTs: string="";
    @observable finishedTs: string | undefined="";
    @observable jobContextType: string="";
    @observable succeded: number=0;
    @observable startedTs: string | undefined="";
    @observable prevError: string | undefined="" as any;
    @observable retryIntervalIndex: number=0;
    @observable nextRunTs: string | undefined="";
    @observable input: any=undefined;
    @observable paused: number=0;
    @observable timesSaved: number=0;
    @observable updatedTs: string="";
    @observable deleted: number | undefined=0;
    @observable state: JobState="" as any;
    @observable stage: string="" as any;
};
*/

export interface DefaultJobStatus {
    id: string;
    key: string;
    priority: number | undefined;
    cancelled: number;
    predecessorsDone: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    prevResult: any | undefined;
    paused: number;
    state: JobState;
}

export interface DefaultSerializedJob {
    id: string;
    key: string;
    priority: number | undefined;
    cancelled: number;
    predecessorsDone: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    prevResult: any | undefined;
    paused: number;
    state: JobState;
}

export interface DefaultSerializedJobs {
    [key: string]: DefaultSerializedJob;
}

export interface DefaultJobsStatus {
    [key: string]: DefaultJobStatus;
}

export interface DefaultJobContextStatus {
    id: string;
    key: string;
    jobsById: any;
    priority: number | undefined;
    predecessorsDone: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobContextType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    paused: number;
    timesSaved: number;
    updatedTs: string;
    deleted: number | undefined;
    state: JobState;
    stage: string;
}

export interface DefaultSerializedJobContext {
    id: string;
    key: string;
    jobsById: any;
    priority: number | undefined;
    predecessorsDone: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobContextType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    input: any;
    paused: number;
    timesSaved: number;
    updatedTs: string;
    state: JobState;
    stage: string;
}

export interface DefaultSerializedJobContextMem {
    id: string;
    key: string;
    priority: number | undefined;
    predecessorsDone: number;
    createdTs: string;
    finishedTs: string | undefined;
    jobContextType: string;
    succeded: number;
    startedTs: string | undefined;
    prevError: string | undefined;
    retryIntervalIndex: number;
    nextRunTs: string | undefined;
    paused: number;
    timesSaved: number;
    updatedTs: string;
    state: JobState;
    stage: string;
}
