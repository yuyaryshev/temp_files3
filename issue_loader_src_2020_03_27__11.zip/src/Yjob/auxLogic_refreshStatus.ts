import { diff as deepObjectDiff } from "deep-object-diff";
import { manageableTimer, mapToObject, writeFileSyncIfChanged } from "Ystd";
import { JobStorage } from "Yjob/JobStorage";
import moment from "moment";
import deepEqual from "fast-deep-equal";

export function refreshStatus<TJobStatus>(jobStorage: JobStorage<any, any, any, any, any>) {
    const pthis = jobStorage;

    if (!jobStorage.jobStorageRefreshStatusTimer)
        jobStorage.jobStorageRefreshStatusTimer = manageableTimer(
            jobStorage.env,
            300,
            `CODE00000297`,
            "jobStorageRefreshStatusTimer",
            () => {
                const ts = moment().format();
                for (let id of pthis.idsTouchedAfterStatus) {
                    const job = pthis.jobContextById.get(id);
                    if (!job) {
                        const jobStatus = pthis.jobsStatus.get(id);
                        if (jobStatus) {
                            jobStatus.updatedTs = ts;
                            jobStatus.deleted = 1;
                            pthis.my_setTimeout(
                                () => {
                                    pthis.jobsStatus.delete(id);
                                },
                                pthis.statusTTL,
                                pthis.env,
                                `CODE00000200`,
                                `JobStorage.startRegularFunc`
                            );
                        }
                    } else {
                        const { updatedTs, ...oldJobStatus } = pthis.jobsStatus.get(id) || (({} as any) as TJobStatus);
                        const newJobStatus = pthis.jobFieldFuncs.serializeStatus(job);
                        if (!updatedTs || !deepEqual(oldJobStatus, newJobStatus)) {
                            newJobStatus.updatedTs = ts;
                            pthis.jobsStatus.set(id, newJobStatus as any);
                        }
                    }
                }

                ////////////////////// TODO Закомментить этот блок, если он никогда не останавилвается на Breakpoint'е внутри этого блока START ////////////////////
                const map2 = new Map();
                for (let [, job] of pthis.jobContextById) map2.set(job.id, pthis.jobFieldFuncs.serializeStatus(job));

                const DBG_RemoveKnownDiffs = (m: any) => {
                    const mo = mapToObject(m) as any;
                    for (let k in mo) {
                        const o = mo[k];
                        if (o) {
                            delete o.updatedTs;
                            if (o.deleted) delete o[k];
                        }
                    }
                    return mo;
                };

                const pthis_jobsStatus_as_object = DBG_RemoveKnownDiffs(pthis.jobsStatus);
                const map2_as_object = DBG_RemoveKnownDiffs(map2);

                if (!deepEqual(pthis_jobsStatus_as_object, map2_as_object)) {
                    const diff = deepObjectDiff(pthis_jobsStatus_as_object, map2_as_object);

                    // debugger;
                    // , diff
                    pthis.my_console.log(`CODE00000099`, `incremental status is different from full status!!!`);
                }
                jobStorage.jobStorageRefreshStatusTimer.setTimeout();

                ////////////////////// TODO Закомментить этот блок, если он никогда не останавилвается на Breakpoint'е внутри этого блока END ////////////////////

                pthis.idsTouchedAfterStatus = new Set();
            }
        );
}
