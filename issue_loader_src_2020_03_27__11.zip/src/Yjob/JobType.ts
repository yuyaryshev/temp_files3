import { awaitDelay, EnvWithTimers, manageableTimer, ReversePromise, reversePromiseResolveItem } from "Ystd";
import { Job, JobDependencyItem, ObserverItem } from "./Job";
import { JobStorage } from "./JobStorage";
import { JobWaitingDepsException, JobWaitingDepsSymbol } from "./JobWaitingDepsException";
import { v4 as uuid } from "uuid";
import { runJob } from "./mainLogic_JobLifeCycle";
import { JobContext } from "Yjob/JobContext";
import { JobContextType } from "Yjob/JobContextType";
import { makeJobContextKey, makeJobKey } from "Yjob/makeJobKey";
import {
    DefaultJobContextStatus,
    DefaultJobStatus,
    DefaultSerializedJob,
    DefaultSerializedJobContext,
} from "Yjob/JobFieldsServer";
import { JobResources } from "Yjob/JobResources";
import { checkPredecessors, setPredecessor } from "Yjob/predecessors";

export type GetContextInputFunc<
    TEnv extends EnvWithTimers = any,
    TContext extends JobContext<any> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> = (env: TEnv, job: Job<TEnv, TContext, TIn, TOut>, input: TIn) => TContextIn;
export type PresetDepsFunc<
    TEnv extends EnvWithTimers = any,
    TContext extends JobContext<any> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> = (env: TEnv, job: Job<TEnv, TContext, TIn, TOut>, contextInput: TContextIn, input: TIn) => void;
export type JobFunc<
    TEnv extends EnvWithTimers = any,
    TContext extends JobContext<any> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> = (env: TEnv, job: Job<TEnv, TContext, TIn, TOut>, contextInput: TContextIn, input: TIn) => TOut | Promise<TOut>;

export interface JobTypeInput<
    TEnv extends EnvWithTimers = any,
    TContext extends JobContext<any> = any,
    TContextIn = any,
    TIn = any,
    TOut = any
> {
    cpl: string;
    type: string;
    stage?: string;
    resources?: JobResources;
    jobContextType: JobContextType;
    presetDepsFunc?: PresetDepsFunc<TEnv, TContext, TContextIn, TIn, TOut>;
    func: JobFunc<TEnv, TContext, TContextIn, TIn, TOut>;
}

export class JobType<
    TEnv extends EnvWithTimers = any,
    TContextIn = any,
    TIn = any,
    TOut = any,
    TContext extends JobContext<any> = JobContext<any>,
    TJob extends Job = Job,
    TSerializedJobContext extends DefaultSerializedJobContext = DefaultSerializedJobContext,
    TJobContextStatus extends DefaultJobContextStatus = DefaultJobContextStatus,
    TSerializedJob extends DefaultSerializedJob = DefaultSerializedJob,
    TJobStatus extends DefaultJobStatus = DefaultJobStatus
> implements JobTypeInput<TEnv, TContext, TContextIn, TIn, TOut> {
    cpl: string;
    type: string;
    stage: string;
    resources: JobResources;
    jobContextType: JobContextType;
    presetDepsFunc?: PresetDepsFunc<TEnv, TContext, TContextIn, TIn, TOut>;
    func: JobFunc<TEnv, TContext, TContextIn, TIn, TOut>;

    constructor(input: JobTypeInput<TEnv, TContext, TContextIn, TIn, TOut>) {
        this.cpl = input.cpl;
        this.type = input.type;
        this.stage = input.stage || input.type;
        this.resources = input.resources || {};
        this.jobContextType = input.jobContextType;

        if (!this.cpl || !this.cpl.length) throw new Error(`CODE00000293 Can't create JobType without cpl!`);
        if (!this.type || !this.type.length)
            throw new Error(`CODE00000294 Can't create JobType type === undefined or empty !`);

        this.presetDepsFunc = input.presetDepsFunc;
        this.func = input.func;
    }

    dep(parent: Job, input: TIn & TContextIn) {
        // TODO добавить в parent dep на child создаваемый через input
        const jobStorage = parent.jobStorage;
        const parentContext = parent?.jobContext;
        const { contextInput, jobInput, customFields } = this.jobContextType.extractInputFunc(jobStorage.env, input);
        const jobContextKey = makeJobContextKey(this.jobContextType.type, contextInput);
        const jobKey = makeJobKey(this.type, jobInput);
        let newJob: boolean = false;

        let jobContext0: JobContext<TEnv, any, any, any, any, any> | undefined =
            parentContext?.key === jobContextKey ? parentContext : undefined;

        // TODO переделываю тело функции ниже... Остановился тут
        // Нужно просто создать Dep у parent от job, который задается через input
        /////////////////////////////////////////////

        const jobContext = jobContext0! || this.jobContextType.open(jobStorage as any, contextInput);

        let job: Job = jobContext.getJobByKey(jobKey)!;
        if (!job) {
            newJob = true;
            const jobId = uuid();
            job = new Job<TEnv, TContext, TIn, TOut>(
                (this as any) as JobType,
                jobContext,
                jobInput,
                jobId,
                jobKey,
                parent?.id
            );
            jobContext.addJob(job);
            for (let handler of job.jobStorage.onJobCreatedHandlers) handler(job, "CODE00000177");
        }

        if (parent) setPredecessor(job, parent);

        if (newJob && this.presetDepsFunc) {
            this.presetDepsFunc(jobStorage.env, job, contextInput, input);
            checkPredecessors(job);
        }

        // Not found in context, search in JobStorage or create a new job
        // TODO тут нужно в будущем обработать external JobContext
        // if (extendedFields)
        //     for (let fieldKey in extendedFields)
        //         if (extendedFields.hasOwnProperty(fieldKey) && (job as any)[fieldKey] !== extendedFields[fieldKey])
        //             (job as any)[fieldKey] = extendedFields[fieldKey];
    }

    run(
        jobStorage: JobStorage<TEnv, TSerializedJobContext, TJobContextStatus, TSerializedJob, TJobStatus>,
        parent: Job | undefined,
        input: TIn & TContextIn,
        forceStale?: boolean,
        extendedFields?: any,
        creationReversePromise?: ReversePromise
    ): Promise<TOut | JobWaitingDepsException | Symbol> | TOut | JobWaitingDepsException | Symbol {
        const parentContext = parent?.jobContext;
        const { contextInput, jobInput, customFields } = this.jobContextType.extractInputFunc(jobStorage.env, input);
        const jobContextKey = makeJobContextKey(this.jobContextType.type, contextInput);
        const jobKey = makeJobKey(this.type, jobInput);
        let newJob: boolean = false;

        let jobContext0: JobContext<TEnv, any, any, any, any, any> | undefined =
            parentContext?.key === jobContextKey ? parentContext : undefined;

        if (!jobContext0 && parentContext) {
            const depItem = parentContext.externalDeps_get(jobKey);
            if (depItem?.succeded) {
                reversePromiseResolveItem(creationReversePromise);
                return depItem.result;
            }
        }

        const jobContext =
            jobContext0! ||
            this.jobContextType.open(
                jobStorage as any,
                contextInput,
                false,
                Object.assign({}, extendedFields, customFields),
                undefined
            );

        let job: Job = jobContext.getJobByKey(jobKey)!;
        if (!job) {
            newJob = true;
            const jobId = uuid();
            job = new Job<TEnv, TContext, TIn, TOut>(
                (this as any) as JobType,
                jobContext,
                jobInput,
                jobId,
                jobKey,
                parent?.id
            );
            jobContext.addJob(job);
            for (let handler of job.jobStorage.onJobCreatedHandlers) handler(job, "CODE00000234");
        }

        if (parent) setPredecessor(job, parent);

        // Not found in context, search in JobStorage or create a new job
        if (extendedFields)
            for (let fieldKey in extendedFields)
                if (extendedFields.hasOwnProperty(fieldKey) && (job as any)[fieldKey] !== extendedFields[fieldKey])
                    (job as any)[fieldKey] = extendedFields[fieldKey];

        if (forceStale) job.makeStale();

        reversePromiseResolveItem(creationReversePromise);

        // Function ending - save job result into parent's context and return the result
        const tailFunc = () => {
            if (parent) setPredecessor(job, parent);

            return job.prevResult;
        };

        // If the job is finished - return result immediatly
        if (job.succeded) return tailFunc();

        if (!parent) {
            jobStorage.insertedNewJob();
            return JobWaitingDepsSymbol;
        }

        if (newJob && this.presetDepsFunc) {
            this.presetDepsFunc(jobStorage.env, job, contextInput, input);
            checkPredecessors(job);
        }

        if (!job.predecessorsDone) return JobWaitingDepsSymbol;

        // Job isn't finished yet. Async mode...
        return (async function awaitRunJob() {
            if (!job.running) runJob(job); // NO AWAIT HERE! Await is below implemented with await awaitDelay & while!

            if (jobStorage.maxAwaitBeforeUnload <= 0) return JobWaitingDepsSymbol;

            // Wait for a while for job to finish without unloading it
            // Later unload the job if waiting for too long (jobStorage.maxAwaitBeforeUnload)
            let totalAwaitTime = 0;

            let delay = 10;
            while (totalAwaitTime < 50) {
                totalAwaitTime += delay;
                if (jobStorage.closing || job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
                    return JobWaitingDepsSymbol;
                await awaitDelay(delay);
                if (job.succeded) return tailFunc();
            }

            return JobWaitingDepsSymbol;

            // delay = 30;
            // while (totalAwaitTime < 500) {
            //     totalAwaitTime += delay;
            //     if (jobStorage.closing || job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
            //         return new JobWaitingDepsException("CODE00000314");
            //     await awaitDelay(delay);
            //     if (job.succeded) return tailFunc();
            // }
            //
            // delay = 100;
            // while (totalAwaitTime < 5000) {
            //     totalAwaitTime += delay;
            //     if (jobStorage.closing || job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
            //         return new JobWaitingDepsException("CODE00000299");
            //     await awaitDelay(delay);
            //     if (job.succeded) return tailFunc();
            // }
            //
            // delay = 300;
            // while (true) {
            //     totalAwaitTime += delay;
            //     if (jobStorage.closing || job.unloaded || totalAwaitTime >= jobStorage.maxAwaitBeforeUnload)
            //         return new JobWaitingDepsException("CODE00000319");
            //     await awaitDelay(delay);
            //     if (job.succeded) return tailFunc();
            // }
        })();
    }
}

export async function throwUnload<T>(
    promise: Promise<T | JobWaitingDepsException | Symbol> | T | JobWaitingDepsException | Symbol
): Promise<T> {
    const r = await promise;
    if (r === JobWaitingDepsSymbol) throw new JobWaitingDepsException("CODE00000320");

    if (r instanceof JobWaitingDepsException) throw r;
    return r as any;
}
