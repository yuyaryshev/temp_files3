import { Job, JobDependencyItem, JobId } from "Yjob/Job";
import { state_Stale } from "Yjob/mainLogic_JobLifeCycle";

export function hasSuccessor(predecessor: Job, successorId: JobId) {
    for (let s of predecessor.successors) if (s === successorId || s[1] === successorId) return true;
    return false;
}

export function setPredecessor(predecessor: Job, successor: Job) {
    let depRecord: JobDependencyItem = {
        succeded: predecessor.succeded,
        id: successor.id,
        result: predecessor.succeded ? predecessor.prevResult : undefined,
    };

    if (predecessor.jobContext === successor.jobContext) {
        if (!hasSuccessor(predecessor, successor.id)) predecessor.successors.push(successor.id);
        successor.predecessors.set(predecessor.id, depRecord);
    } else {
        if (!hasSuccessor(predecessor, successor.id))
            predecessor.successors.push([successor.jobContext.id, successor.id]);
        depRecord.jobContextId = predecessor.jobContext.id;
        successor.predecessors.set(predecessor.id, depRecord);
    }
}

export const checkPredecessors = (job: Job) => {
    for (let [, predecessor] of job.predecessors)
        if (!predecessor.succeded) {
            // If so, the result is stale
            job.predecessorsDone = false;
            return false;
        }
    job.predecessorsDone = true;
    return true;
};

export const notifySuccessors = (predecessor: Job) => {
    for (let successorItem of predecessor.successors) {
        const successorJob =
            typeof successorItem === "string"
                ? predecessor.jobContext.getJobById(successorItem)
                : predecessor.jobStorage.findJobById(successorItem[0], successorItem[1]);

        if (successorJob) {
            predecessor.predecessors.set(predecessor.key, {
                id: predecessor.id,
                succeded: predecessor.succeded,
                result: predecessor.succeded && predecessor.prevResult,
            });
            if (checkPredecessors(successorJob)) {
                state_Stale(successorJob);
                successorJob.jobStorage.updateJobState(successorJob);
            }
        }
    }
};
